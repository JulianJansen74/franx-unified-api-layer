﻿namespace Abf.Account.Api.Configuration;

public class AzureEnvironmentSettings
{
    public string Environment { get; set; }
}
