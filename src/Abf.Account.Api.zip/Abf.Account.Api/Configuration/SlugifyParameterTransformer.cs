using System.Text.RegularExpressions;

namespace Abf.Account.Api.Configuration
{
    /// <summary>
    /// Formats the slug of a URL to become adhere to a kebab-case convention.
    /// </summary>
    public class SlugifyParameterTransformer : IOutboundParameterTransformer
    {
        private const int TimeoutMs = 50;

        public string TransformOutbound(object value)
        {
            if (value == null)
            {
                return "";
            }

            return Regex.Replace(value.ToString(), "([a-z])([A-Z])", "$1-$2", RegexOptions.CultureInvariant,
                TimeSpan.FromMilliseconds(TimeoutMs)).ToLowerInvariant();
        }
    }
}
