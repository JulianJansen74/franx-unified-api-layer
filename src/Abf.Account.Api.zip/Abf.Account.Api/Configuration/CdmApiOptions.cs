﻿using System.ComponentModel.DataAnnotations;

namespace Abf.Account.Api.Configuration
{
    /// <summary>
    /// Cdm api options
    /// </summary>
    public class CdmApiOptions
    {
        /// <summary>
        /// Required base url
        /// </summary>
        [Required]
        public string BaseUrl { get; set; }
    }
}
