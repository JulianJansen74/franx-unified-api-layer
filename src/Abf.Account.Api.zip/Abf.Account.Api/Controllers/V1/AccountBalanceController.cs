﻿using System.Net.Mime;
using Abf.Account.Api.Authorization;
using Abf.Account.Api.Extensions;
using Abf.Account.Models.AccountBalance;
using Abf.Account.Routers;
using Abf.Account.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Abf.Account.Api.Controllers.V1
{
    [ApiController]
    [Authorize(Policy = Roles.AccountBalances)]
    [ApiVersion("1.0")]
    [Consumes(MediaTypeNames.Application.Json)]
    [Produces(MediaTypeNames.Application.Json)]
    [Route("api/v{version:apiVersion}/account-balances")]
    public class AccountBalanceController(
        IBackofficeRouterFactory backofficeRouterFactory)
        : ControllerBase
    {
        [HttpGet]
        [ProducesResponseType(typeof(AccountBalance[]), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetAsync([FromQuery] AccountBalanceRequest request,
            CancellationToken cancellationToken)
        {
            var router =
                await backofficeRouterFactory.GetRouterByAccountNumberWithFallbackAsync<IAccountBalanceRouter>(
                    request.BbanAccountNumber, cancellationToken);

            var accountBalances = await router.GetAccountBalances(request, cancellationToken);

            if (accountBalances == null)
            {
                return this.InternalServerErrorProblem();
            }

            return Ok(accountBalances);
        }
    }
}
