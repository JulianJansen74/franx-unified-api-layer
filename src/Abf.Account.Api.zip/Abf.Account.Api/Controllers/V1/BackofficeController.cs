﻿using System.Net.Mime;
using Abf.Account.AccountApiData.Entities;
using Abf.Account.Api.Authorization;
using Abf.Account.Api.Extensions;
using Abf.Account.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Abf.Account.Api.Controllers.V1
{
    [ApiController]
    [Authorize(Policy = Roles.AccountCreate)]
    [ApiVersion("1.0")]
    [Consumes(MediaTypeNames.Application.Json)]
    [Produces(MediaTypeNames.Application.Json)]
    [Route("api/v{version:apiVersion}/backoffices")]
    public class BackofficeController(
        IBackofficeRepository backofficeRepository,
        IBackofficeAccountRepository backofficeAccountRepository)
        : ControllerBase
    {
        [HttpGet]
        [ProducesResponseType(typeof(Backoffice[]), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetBackofficesAsync(CancellationToken cancellationToken)
        {
            var backoffices = await backofficeRepository.GetAllAsync(cancellationToken);
            return Ok(backoffices);
        }

        [HttpGet("{backofficeId}/accounts")]
        [ProducesResponseType(typeof(BackofficeAccount[]), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetAccountsByBackofficeAsync(int backofficeId)
        {
            var accounts = await backofficeAccountRepository.GetByBackofficeIdAsync(backofficeId);
            return Ok(accounts);
        }

        [HttpPost("accounts")]
        [ProducesResponseType(typeof(BackofficeAccount), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreateAccountAsync([FromBody] BackofficeAccount account)
        {
            var createdAccount = await backofficeAccountRepository.CreateAsync(account);
            return CreatedAtAction(nameof(GetAccountAsync), new
            {
                accountNumber = createdAccount.AccountNumber
            }, createdAccount);
        }

        [HttpGet("accounts/{accountNumber}")]
        [ProducesResponseType(typeof(BackofficeAccount), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetAccountAsync(string accountNumber, CancellationToken cancellationToken)
        {
            var account = await backofficeAccountRepository.GetByAccountNumberAsync(accountNumber, cancellationToken);
            if (account == null)
            {
                return this.NotFoundProblem();
            }

            return Ok(account);
        }
    }
}
