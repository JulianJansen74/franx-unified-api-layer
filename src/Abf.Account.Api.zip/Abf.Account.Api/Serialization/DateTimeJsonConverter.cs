using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Abf.Account.Api.Serialization
{
    public class DateTimeJsonConverter : JsonConverter<DateTime>
    {
        private const string DateFormat = "yyyy-MM-dd";
        private const string DateTimeFormat = "yyyy-MM-dd'T'HH:mm:ss.FFFFFFF";
        private const string UtcDateTimeFormat = "yyyy-MM-dd'T'HH:mm:ss.FFFFFFF'Z'";

        public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            return DateTime.Parse(reader.GetString(), CultureInfo.InvariantCulture);
        }

        public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
        {
            // In the absence of a dedicated type in C# for dates, we do an attempt to
            // recognise when a date is intended. In case we evaluate the date time to
            // actually be a date, we flush out a format that does not comprise of a time
            // part.
            if (value.Kind == DateTimeKind.Unspecified)
            {
                var format = DateTimeFormat;
                if (value.TimeOfDay.Ticks == 0)
                {
                    format = DateFormat;
                }

                writer?.WriteStringValue(value.ToString(format));
            }
            else
            {
                writer?.WriteStringValue(value.ToUniversalTime().ToString(UtcDateTimeFormat));
            }
        }
    }
}
