using Abf.Account.AccountApiData;
using Abf.Account.Api.Configuration;
using Abf.Account.Api.Constants;
using Abf.Account.Api.ExceptionHandlers;
using Abf.Account.Api.Extensions;
using Abf.Account.Api.HealthChecks;
using Abf.Account.Service.HttpClients.Cdm;
using Abfr.Abn.Gateway.Authentication;
using Abfr.Abn.Gateway.Cdm;
using Abfr.Abn.Gateway.Extensions;
using Franx.Context.AspNetCore;
using Franx.Context.AspNetCore.CorrelationId;
using Franx.Idempotency;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Logging;
using Microsoft.OpenApi.Models;

namespace Abf.Account.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
        {
            Configuration = configuration;
            WebHostEnvironment = webHostEnvironment;
        }

        public IConfiguration Configuration { get; }
        public IWebHostEnvironment WebHostEnvironment { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddOptions<AzureEnvironmentSettings>()
                .Bind(Configuration.GetSection("AzureEnvironment"))
                .ValidateDataAnnotations();

            var connectionString = Configuration.GetConnectionString("Franx.AccountApi");
            if (WebHostEnvironment.EnvironmentName != "IntegrationTesting")
            {
                services.AddDbContext<AccountDbContext>(options => options.UseSqlServer(connectionString,
                    sql =>
                    {
                        sql.MigrationsAssembly(typeof(AccountDbContext).Assembly.FullName);
                        sql.EnableRetryOnFailure();
                    }));
            }

            services.AddContext();
            services.AddHttpContextAccessor();
            services.AddApiHealthChecks(Configuration);
            services.AddMemoryCache();
            services.AddServices();
            services.AddModelValidations();
            services.AddAuth(WebHostEnvironment, Configuration);

            services.AddExceptionHandler<FluentValidationExceptionHandler>();
            services.AddExceptionHandler<DbUpdateExceptionHandler>();
            services.AddExceptionHandler<AppExceptionHandler>();
            services.AddExceptionHandler<GenericExceptionHandler>();
            services.AddProblemDetails();

            ConfigureHttpClients(services, Configuration);
            services.AddAbnAmroGateway(Configuration);
            AddIdempotency(services, connectionString);

            var openApiInfo = new OpenApiInfo
            {
                Title = "Account API",
                Version = "v1",
                Description = "Account operations abstracted away from a specific ledger.",
                Contact = new OpenApiContact { Name = "ABF Team", Email = string.Empty }
            };

            services.AddSwaggerSetup(openApiInfo, Configuration);

#if DEBUG
            IdentityModelEventSource.ShowPII = true;
#elif RELEASE
            IdentityModelEventSource.ShowPII = false;
            services.AddApplicationInsightsTelemetry();
#endif
        }

        private static void AddIdempotency(IServiceCollection services, string connectionString)
        {
            services.AddFranxIdempotency();
            services.AddDistributedSqlServerCache(options =>
            {
                options.ConnectionString = connectionString;
                options.SchemaName = "dbo";
                options.TableName = Account.Constants.SqlDistributedCacheTable;
            });
        }

        protected virtual IServiceCollection ConfigureHttpClients(IServiceCollection services,
            IConfiguration configuration)
        {
            services.AddHttpClient<ICdmApiClient, CdmApiClient>((s, c) =>
            {
                var cdmOptions = s.GetRequiredService<IOptions<CdmApiOptions>>().Value;
                c.BaseAddress = new Uri(cdmOptions.BaseUrl);
            }).AddAzureAdToken(Configuration.GetSection("AzureAd").Bind,
                Configuration.GetValue<string>("CdmApi:Scope"));

            services.AddHttpClient<IAbnAmroCdmConsentClient, CdmAbnAmroConsentClient>((s, c) =>
            {
                var cdmOptions = s.GetRequiredService<IOptions<CdmApiOptions>>().Value;
                c.BaseAddress = new Uri(cdmOptions.BaseUrl);
            }).AddAzureAdToken(configuration.GetSection("AzureAd").Bind,
                configuration.GetValue<string>("CdmApi:Scope"));

            return services;
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IConfiguration configuration)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            if (env.EnvironmentName != "IntegrationTesting")
            {
                MigrateDatabase(app);
            }

            app.UseCorrelationIdInitializer();
            app.UseExceptionHandler();
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseApiHealthChecks();

            app.UseSwagger(c =>
            {
                c.PreSerializeFilters.Add((swaggerDoc, httpReq) =>
                {
                    swaggerDoc.Servers.Add(new OpenApiServer
                    {
                        Url = $"{httpReq.Scheme}://{httpReq.Host}{httpReq.PathBase}"
                    });
                });
            });

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "V1");
                c.OAuthAppName("Adaptive Banking Framework");
                c.OAuthClientId(configuration[Application.AzureAdClientId]);
                c.OAuthUsePkce();
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("backend-account");
                });
            });
        }

        protected virtual void MigrateDatabase(IApplicationBuilder app)
        {
            using var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope();
            var context = serviceScope.ServiceProvider.GetService<AccountDbContext>();
            if (context.Database.IsRelational())
            {
                context.Database.Migrate();
            }
        }
    }
}
