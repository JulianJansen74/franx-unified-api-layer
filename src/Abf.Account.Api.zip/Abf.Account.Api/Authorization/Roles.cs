namespace Abf.Account.Api.Authorization
{
    public static class Roles
    {
        public const string AccountBalances = "account_balances";
        public const string AccountCreate = "account_create";
    }
}
