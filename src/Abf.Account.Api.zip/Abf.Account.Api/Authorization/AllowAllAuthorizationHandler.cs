﻿using Microsoft.AspNetCore.Authorization;

namespace Abf.Account.Api.Authorization
{
    public class AllowAllAuthorizationHandler : IAuthorizationHandler
    {
        public Task HandleAsync(AuthorizationHandlerContext context)
        {
            if (context == null)
            {
                return Task.CompletedTask;
            }

            foreach (var pendingRequirement in context.PendingRequirements.ToList())
            {
                context.Succeed(pendingRequirement);
            }

            return Task.CompletedTask;
        }
    }
}
