using Microsoft.AspNetCore.Authorization;

namespace Abf.Account.Api.Authorization
{
    public static class Policies
    {
        public static void AddPolicies(this AuthorizationOptions options)
        {
            ArgumentNullException.ThrowIfNull(options);

            options.AddPolicy(Roles.AccountBalances, policy =>
            {
                policy.RequireAssertion(x => x.User.IsInRole(Roles.AccountBalances));
            });

            options.AddPolicy(Roles.AccountCreate, policy =>
            {
                policy.RequireAssertion(x => x.User.IsInRole(Roles.AccountCreate));
            });
        }
    }
}
