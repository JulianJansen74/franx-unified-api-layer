﻿using Abf.Account.Api.Extensions;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.EntityFrameworkCore;

namespace Abf.Account.Api.ExceptionHandlers;

public class DbUpdateExceptionHandler(ILogger<DbUpdateExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        if (exception is not DbUpdateException dbUpdateException)
        {
            return false;
        }

        httpContext.Response.ContentType = "application/problem+json";
        return await Extensions.ExceptionHandlers.TryHandleDbUpdateExceptionAsync(httpContext, dbUpdateException, logger);
    }
}
