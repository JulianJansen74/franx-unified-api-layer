﻿using FluentValidation;
using Microsoft.AspNetCore.Diagnostics;

namespace Abf.Account.Api.ExceptionHandlers;

public class FluentValidationExceptionHandler(ILogger<FluentValidationExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        if (exception is not ValidationException validationException)
        {
            return false;
        }

        httpContext.Response.ContentType = "application/problem+json";
        return await Extensions.ExceptionHandlers.TryHandleValidationExceptionAsync(httpContext, validationException,
            logger);
    }
}
