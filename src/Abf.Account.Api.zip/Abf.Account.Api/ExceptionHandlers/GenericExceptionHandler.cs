﻿using Microsoft.AspNetCore.Diagnostics;

namespace Abf.Account.Api.ExceptionHandlers
{
    public class GenericExceptionHandler(
        ILogger<GenericExceptionHandler> logger,
        IConfiguration configuration) : IExceptionHandler
    {
        public async ValueTask<bool> TryHandleAsync(
            HttpContext httpContext,
            Exception exception,
            CancellationToken cancellationToken)
        {
            return await Extensions.ExceptionHandlers.TryHandleGenericExceptionAsync(httpContext, exception, logger,
                true);
        }
    }
}
