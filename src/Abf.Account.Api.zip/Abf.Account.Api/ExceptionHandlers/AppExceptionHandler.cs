﻿using Abf.Account.Api.Configuration;
using Abf.Account.Api.Extensions;
using Abf.Account.Common.Exceptions;
using Microsoft.AspNetCore.Diagnostics;

namespace Abf.Account.Api.ExceptionHandlers;

public class AppExceptionHandler(
    ILogger<AppExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        if (exception is not IAppException appException)
        {
            return false;
        }

        httpContext.Response.ContentType = "application/problem+json";

        return await Extensions.ExceptionHandlers.TryHandleAppExceptionAsync(httpContext, appException, logger);
    }
}
