﻿#nullable enable
using Microsoft.AspNetCore.Mvc;

namespace Abf.Account.Api.Extensions
{
    public static class ControllerExtensions
    {
        public static IActionResult InternalServerErrorProblem(this ControllerBase controller,
            string? detail = null,
            string? title = null)
        {
            return controller.Problem(
                title: title ?? "Internal Server Error",
                detail: detail ?? "An internal server error occurred while processing your request.",
                statusCode: StatusCodes.Status500InternalServerError,
                type: "https://tools.ietf.org/html/rfc7231#section-6.6.1");
        }

        public static IActionResult NotFoundProblem(this ControllerBase controller,
            string? detail = null,
            string? title = null)
        {
            return controller.Problem(
                title: title ?? "Not Found",
                detail: detail ?? "The requested resource was not found.",
                statusCode: StatusCodes.Status404NotFound,
                type: "https://tools.ietf.org/html/rfc7231#section-6.5.4");
        }
    }
}
