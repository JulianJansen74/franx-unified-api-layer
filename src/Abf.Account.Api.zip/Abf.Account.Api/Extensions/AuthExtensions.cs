﻿using Abf.Account.Api.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;

namespace Abf.Account.Api.Extensions
{
    public static class AuthExtensions
    {
        public static void AddAuth(this IServiceCollection services, IWebHostEnvironment environment,
            IConfiguration configuration)
        {
            services.AddAuthentication(options =>
                {
                    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(options =>
                {
                    configuration.GetSection("AzureAd").Bind(options);
                    options.TokenValidationParameters.ValidIssuer = options.Authority + "/v2.0";
                });

            services.AddAuthorization(options =>
            {
                options.AddPolicies();
            });

#if DEBUG
            if (environment.IsDevelopment())
            {
                services.AddSingleton<IAuthorizationHandler, AllowAllAuthorizationHandler>();
            }
#endif
        }
    }
}
