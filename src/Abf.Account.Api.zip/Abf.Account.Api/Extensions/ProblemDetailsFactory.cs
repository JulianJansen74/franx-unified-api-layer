﻿using System.Net;
using Microsoft.AspNetCore.Mvc;

namespace Abf.Account.Api.Extensions;

public static class ProblemDetailsFactory
{
    public static ValidationProblemDetails CreateValidationProblemDetails(HttpContext context,
        IDictionary<string, string[]> errors)
    {
        const int BadRequestStatusCode = (int)HttpStatusCode.BadRequest;

        return new ValidationProblemDetails(errors)
        {
            Status = BadRequestStatusCode,
            Title = "One or more validation errors occurred.",
            Detail = "Please refer to the errors property for additional details.",
            Type = ProblemTypeMapper.GetProblemTypeForStatusCode(BadRequestStatusCode),
            Instance = context.Request.Path
        };
    }

    public static ProblemDetails CreateProblemDetails(int statusCode, string title, string detail)
    {
        return new ProblemDetails
        {
            Status = statusCode,
            Title = title,
            Detail = detail,
            Type = ProblemTypeMapper.GetProblemTypeForStatusCode(statusCode)
        };
    }

    public static string GetGenericErrorMessage(int statusCode) => statusCode switch
    {
        400 => "The request was invalid.",
        401 => "Authentication is required.",
        403 => "Access to this resource is forbidden.",
        404 => "The requested resource was not found.",
        408 => "The request timed out.",
        409 => "There was a conflict with the current state of the resource.",
        422 => "The request could not be processed.",
        500 => "An internal server error occurred.",
        501 => "This functionality is not implemented.",
        502 => "Bad gateway.",
        503 => "The service is temporarily unavailable.",
        _ => "An error occurred while processing your request."
    };
}
