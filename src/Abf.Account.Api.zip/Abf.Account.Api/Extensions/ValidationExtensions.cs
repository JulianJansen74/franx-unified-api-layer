﻿using Abf.Account.Models.AccountBalance;
using FluentValidation;

namespace Abf.Account.Api.Extensions
{
    public static class ValidationExtensions
    {
        public static IServiceCollection AddModelValidations(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<IValidator<AccountBalanceRequest>, AccountBalanceRequestValidator>();

            return serviceCollection;
        }
    }
}
