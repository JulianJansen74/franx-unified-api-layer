﻿using Abf.Account.Common.Exceptions;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Abf.Account.Api.Extensions;

public static class ExceptionHandlers
{
    private const string DefaultParameterName = "parameter";

    public static async Task<bool> TryHandleValidationExceptionAsync(HttpContext context,
        ValidationException validationException, ILogger logger)
    {
        logger.LogError(validationException, "AbfrAccount ValidationException exception has thrown");

        var errors = validationException.Errors
            .GroupBy(error => error.PropertyName, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(
                errorGroup => errorGroup.Key,
                errorGroup => errorGroup.Select(error => error.ErrorMessage).ToArray(),
                StringComparer.OrdinalIgnoreCase
            );

        var problemDetails = ProblemDetailsFactory.CreateValidationProblemDetails(context, errors);
        await context.Response.WriteAsJsonAsync(problemDetails);
        return true;
    }

    public static async Task<bool> TryHandleDbUpdateExceptionAsync(HttpContext context,
        DbUpdateException dbUpdateException, ILogger logger)
    {
        logger.LogError(dbUpdateException, "AbfrAccount DbUpdateException exception has thrown");

        var errors = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            [DefaultParameterName] = [dbUpdateException.InnerException?.Message ?? dbUpdateException.Message]
        };

        var problemDetails = ProblemDetailsFactory.CreateValidationProblemDetails(context, errors);
        await context.Response.WriteAsJsonAsync(problemDetails);
        return true;
    }

    public static async Task<bool> TryHandleAppExceptionAsync(HttpContext context, IAppException appException,
        ILogger logger)
    {
        logger.LogError((Exception)appException, "AbfrAccount Application exception has thrown");

        context.Response.StatusCode = (int)appException.HttpStatusCode;

        var statusCode = (int)appException.HttpStatusCode;

        var problemDetails = ProblemDetailsFactory.CreateProblemDetails(
            statusCode,
            appException.ErrorKey,
            appException.Detail
        );

        await context.Response.WriteAsJsonAsync(problemDetails);
        return true;
    }

    public static async Task<bool> TryHandleGenericExceptionAsync(HttpContext context, Exception exception,
        ILogger logger, bool showDetails)
    {
        var statusCode = StatusCodeMapper.GetStatusCodeForException(exception);

        logger.LogError(exception, "AbfrAccount exception occurred: {ExceptionType}", exception.GetType().Name);

        context.Response.StatusCode = statusCode;

        var shouldShowDetail = showDetails || statusCode < 500;

        var problemDetails = ProblemDetailsFactory.CreateProblemDetails(
            statusCode,
            shouldShowDetail ? exception.GetType().Name : "Error",
            shouldShowDetail ? exception.Message : ProblemDetailsFactory.GetGenericErrorMessage(statusCode)
        );

        await context.Response.WriteAsJsonAsync(problemDetails);
        return true;
    }
}
