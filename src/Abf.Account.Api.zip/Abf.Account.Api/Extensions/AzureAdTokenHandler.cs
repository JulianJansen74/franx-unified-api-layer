﻿using Azure.Core;

namespace Abf.Account.Api.Extensions
{
    public class AzureAdTokenHandler : DelegatingHandler
    {
        private readonly TokenCredential _tokenCredential;
        private readonly string _scope;

        public AzureAdTokenHandler(TokenCredential tokenCredential, string scope)
        {
            _tokenCredential = tokenCredential;
            _scope = scope;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var token = await _tokenCredential.GetTokenAsync(new TokenRequestContext(new[] { _scope }), cancellationToken);

            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token.Token);

            return await base.SendAsync(request, cancellationToken);
        }
    }
}
