﻿using System.Reflection;

using Abf.Account.Api.Filters;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace Abf.Account.Api.Extensions
{
    public static class SwaggerExtensions
    {
        public static IServiceCollection AddSwaggerSetup(this IServiceCollection services, OpenApiInfo openApiInfo, IConfiguration configuration)
        {
            var scopes = new Dictionary<string, string>
            {
                { $"{configuration?[Constants.Application.AzureAdAudience]}/{Constants.Application.SwaggerScope}", "ABF Account API" }
            };

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc(openApiInfo.Version, openApiInfo);
                options.OperationFilter<AuthorizeCheckOperationFilter>();
                options.OperationFilter<QueryParameterCamelCaseFilter>();

                options.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
                {
                    Type = SecuritySchemeType.OAuth2,
                    OpenIdConnectUrl = new Uri($"{configuration[Constants.Application.AzureAdAuthority]}/.well-known/openid-configuration"),
                    Flows = new OpenApiOAuthFlows
                    {
                        AuthorizationCode = new OpenApiOAuthFlow
                        {
                            AuthorizationUrl = new Uri($"{configuration[Constants.Application.AzureAdAuthority]}/oauth2/v2.0/authorize"),
                            TokenUrl = new Uri($"{configuration[Constants.Application.AzureAdAuthority]}/oauth2/v2.0/token"),
                            Scopes = scopes
                        }
                    }
                });

                IncludeXmlCommentsOfAllSolutionAssemblies(options);
            });

            return services;
        }

        private static void IncludeXmlCommentsOfAllSolutionAssemblies(SwaggerGenOptions options)
        {
            var entryAssembly = Assembly.GetEntryAssembly() ?? throw new Exception("Unable to determine entry assembly");
            var entryAssemblyName = entryAssembly.GetName().Name ?? throw new Exception("Unable to determine entry assembly name");
            var baseAssemblyName = entryAssemblyName.Substring(0, entryAssemblyName.LastIndexOf('.') + 1);
            var projectAssemblyNames = entryAssembly.GetReferencedAssemblies()
                .ToList()
                .FindAll(a => a?.Name != null && a.Name.StartsWith(baseAssemblyName, StringComparison.InvariantCultureIgnoreCase))
                .ConvertAll(a => a.Name);

            projectAssemblyNames.Add(entryAssemblyName);

            foreach (string projectAssemblyName in projectAssemblyNames)
            {
                var xmlFiles = Directory.GetFiles(AppContext.BaseDirectory, $"{projectAssemblyName}.xml", SearchOption.TopDirectoryOnly);
                foreach (var xmlFile in xmlFiles)
                {
                    options.IncludeXmlComments(xmlFile);
                }
            }
        }
    }
}
