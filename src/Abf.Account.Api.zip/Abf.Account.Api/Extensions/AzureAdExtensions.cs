﻿using Azure.Core;
using Azure.Identity;

namespace Abf.Account.Api.Extensions
{
    public static class AzureAdExtensions
    {
        public static IHttpClientBuilder AddAzureAdToken(this IHttpClientBuilder builder,
            Action<AzureAdTokenOptions> configureOptions, string scope)
        {
            var options = new AzureAdTokenOptions();
            configureOptions.Invoke(options);

            TokenCredential tokenCredential = !string.IsNullOrEmpty(options.ClientSecret) ?
                new ClientSecretCredential(options.Authority.AbsolutePath.Trim('/'), options.ClientId, options.ClientSecret) :
                new DefaultAzureCredential(new DefaultAzureCredentialOptions { ExcludeEnvironmentCredential = true });

            return builder.AddHttpMessageHandler(serviceProvider =>
            {
                return new AzureAdTokenHandler(tokenCredential, scope);
            });
        }
    }
}
