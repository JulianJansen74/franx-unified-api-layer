namespace Abf.Account.Api.Extensions
{
    public static class StringExtensions
    {
        public static string LowerCaseFirstLetter(this string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return input;
            }

            return char.ToLowerInvariant(input[0]) + input.Substring(1);
        }
    }
}