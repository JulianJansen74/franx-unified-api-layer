﻿namespace Abf.Account.Api.Extensions;

public static class ProblemTypeMapper
{
    public static string GetProblemTypeForStatusCode(int statusCode) => statusCode switch
    {
        400 => "https://tools.ietf.org/html/rfc7231#section-6.5.1", // Bad Request
        401 => "https://tools.ietf.org/html/rfc7235#section-3.1", // Unauthorized
        403 => "https://tools.ietf.org/html/rfc7231#section-6.5.3", // Forbidden
        404 => "https://tools.ietf.org/html/rfc7231#section-6.5.4", // Not Found
        405 => "https://tools.ietf.org/html/rfc7231#section-6.5.5", // Method Not Allowed
        406 => "https://tools.ietf.org/html/rfc7231#section-6.5.6", // Not Acceptable
        408 => "https://tools.ietf.org/html/rfc7231#section-6.5.7", // Request Timeout
        409 => "https://tools.ietf.org/html/rfc7231#section-6.5.8", // Conflict
        410 => "https://tools.ietf.org/html/rfc7231#section-6.5.9", // Gone
        411 => "https://tools.ietf.org/html/rfc7231#section-6.5.10", // Length Required
        412 => "https://tools.ietf.org/html/rfc7232#section-4.2", // Precondition Failed
        413 => "https://tools.ietf.org/html/rfc7231#section-6.5.11", // Payload Too Large
        414 => "https://tools.ietf.org/html/rfc7231#section-6.5.12", // URI Too Long
        415 => "https://tools.ietf.org/html/rfc7231#section-6.5.13", // Unsupported Media Type
        416 => "https://tools.ietf.org/html/rfc7233#section-4.4", // Range Not Satisfiable
        417 => "https://tools.ietf.org/html/rfc7231#section-6.5.14", // Expectation Failed
        422 => "https://tools.ietf.org/html/rfc4918#section-11.2", // Unprocessable Entity
        423 => "https://tools.ietf.org/html/rfc4918#section-11.3", // Locked
        424 => "https://tools.ietf.org/html/rfc4918#section-11.4", // Failed Dependency
        426 => "https://tools.ietf.org/html/rfc7231#section-6.5.15", // Upgrade Required
        428 => "https://tools.ietf.org/html/rfc6585#section-3", // Precondition Required
        429 => "https://tools.ietf.org/html/rfc6585#section-4", // Too Many Requests
        431 => "https://tools.ietf.org/html/rfc6585#section-5", // Request Header Fields Too Large
        500 => "https://tools.ietf.org/html/rfc7231#section-6.6.1", // Internal Server Error
        501 => "https://tools.ietf.org/html/rfc7231#section-6.6.2", // Not Implemented
        502 => "https://tools.ietf.org/html/rfc7231#section-6.6.3", // Bad Gateway
        503 => "https://tools.ietf.org/html/rfc7231#section-6.6.4", // Service Unavailable
        504 => "https://tools.ietf.org/html/rfc7231#section-6.6.5", // Gateway Timeout
        505 => "https://tools.ietf.org/html/rfc7231#section-6.6.6", // HTTP Version Not Supported
        _ => "https://tools.ietf.org/html/rfc7231#section-6.6.1" // Default to Internal Server Error
    };
}
