﻿using System.Security;

namespace Abf.Account.Api.Extensions;

public static class StatusCodeMapper
{
    public static int GetStatusCodeForException(Exception ex) => ex switch
    {
        // Most specific argument exceptions first - Bad Request (400)
        ArgumentNullException => StatusCodes.Status400BadRequest,
        ArgumentOutOfRangeException => StatusCodes.Status400BadRequest,
        ArgumentException => StatusCodes.Status400BadRequest,

        // Format and parsing exceptions - Bad Request (400)
        FormatException => StatusCodes.Status400BadRequest,
        OverflowException => StatusCodes.Status400BadRequest,

        // Not found exceptions - Not Found (404)
        KeyNotFoundException => StatusCodes.Status404NotFound,
        FileNotFoundException => StatusCodes.Status404NotFound,
        DirectoryNotFoundException => StatusCodes.Status404NotFound,

        // Security and access exceptions - Forbidden (403)
        UnauthorizedAccessException => StatusCodes.Status403Forbidden,
        SecurityException => StatusCodes.Status403Forbidden,

        // Timeout exceptions - Request Timeout (408) - TaskCanceledException inherits from OperationCanceledException
        TaskCanceledException => StatusCodes.Status408RequestTimeout,
        OperationCanceledException => StatusCodes.Status408RequestTimeout,
        TimeoutException => StatusCodes.Status408RequestTimeout,

        // Operation state exceptions - Conflict (409) - Most specific first
        ObjectDisposedException => StatusCodes.Status500InternalServerError,
        InvalidOperationException => StatusCodes.Status500InternalServerError,

        // Not supported exceptions - Not Implemented (501) - Most specific first
        NotImplementedException => StatusCodes.Status501NotImplemented,
        PlatformNotSupportedException => StatusCodes.Status501NotImplemented,
        NotSupportedException => StatusCodes.Status501NotImplemented,

        // Default to Internal Server Error (500)
        _ => StatusCodes.Status500InternalServerError
    };
}
