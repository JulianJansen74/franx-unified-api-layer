using Abf.Account.Common;
using Abf.Account.Router.AbnRouters;
using Abf.Account.Routers;
using Abf.Account.Service;
using AccountBalanceService = Abf.Account.Service.AccountBalanceService;
using IAccountBalanceService = Abf.Account.Service.IAccountBalanceService;

namespace Abf.Account.Api.Extensions
{
    public static class DependencyInjectionExtensions
    {
        public static IServiceCollection AddServices(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddScoped<IAccountBalanceService, AccountBalanceService>();
            serviceCollection.AddScoped<IBackofficeAccountService, BackofficeAccountService>();
            serviceCollection.AddScoped<IBackofficeRouterFactory, BackofficeRouterFactory>();
            serviceCollection.AddKeyedRouters();

            return serviceCollection;
        }

        public static IServiceCollection AddKeyedRouters(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddKeyedScoped<IAccountBalanceRouter, AbnAccountBalanceRouter>(BackofficeName.AbnAmro);

            return serviceCollection;
        }
    }
}
