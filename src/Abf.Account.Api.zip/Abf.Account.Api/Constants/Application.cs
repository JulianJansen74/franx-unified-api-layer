﻿namespace Abf.Account.Api.Constants
{
    public static class Application
    {
        public const string AzureAdAudience = "AzureAd:Audience";

        public const string AzureAdAuthority = "AzureAd:Authority";

        public const string AzureAdClientId = "AzureAd:ClientId";

        public const string SwaggerScope = "user_impersonation";
    }
}
