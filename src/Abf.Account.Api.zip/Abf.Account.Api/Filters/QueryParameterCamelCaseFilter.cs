﻿using Microsoft.OpenApi.Models;

using Swashbuckle.AspNetCore.SwaggerGen;

using Abf.Account.Api.Extensions;

namespace Abf.Account.Api.Filters
{
    public class QueryParameterCamelCaseFilter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (operation?.Parameters != null)
            {
                foreach (OpenApiParameter parameter in operation.Parameters.Where(x => x.In == ParameterLocation.Query))
                {
                    parameter.Name = parameter.Name.LowerCaseFirstLetter();
                }
            }
        }
    }
}
