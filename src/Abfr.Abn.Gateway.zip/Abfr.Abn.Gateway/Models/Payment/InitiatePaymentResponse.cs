using System.Text.Json.Serialization;

namespace Abfr.Abn.Gateway.Models.Payment;

public sealed record InitiatePaymentResponse(
    [property: JsonPropertyName("accountNumber")]
    string AccountNumber,
    [property: JsonPropertyName("paymentId")]
    string PaymentId);
