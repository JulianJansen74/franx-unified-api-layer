using System.Text.Json.Serialization;

namespace Abfr.Abn.Gateway.Models.Payment;

public sealed record PaymentStatusResponse(
    [property: JsonPropertyName("paymentId")]
    string PaymentId,
    [property: JsonPropertyName("status")]
    string Status);
