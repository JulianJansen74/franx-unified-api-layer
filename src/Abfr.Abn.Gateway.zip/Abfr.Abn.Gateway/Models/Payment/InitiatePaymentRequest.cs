using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Abfr.Abn.Gateway.Models.Payment;

public sealed record InitiatePaymentRequest(
    [property: Required]
    [property: MinLength(10)]
    [property: MaxLength(18)]
    [property: JsonPropertyName("fileName")]
    string FileName,
    [property: Required]
    [property: JsonPropertyName("fileData")]
    string FileData);
