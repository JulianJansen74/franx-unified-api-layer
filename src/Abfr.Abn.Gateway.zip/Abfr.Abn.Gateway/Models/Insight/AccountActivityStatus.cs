namespace Abfr.Abn.Gateway.Models.Insight;

public static class AccountActivityStatus
{
    public const string Active = "ACTIVE";
    public const string Cancelled = "CANCELLED";
    public const string Booked = "BOOKED";
}
