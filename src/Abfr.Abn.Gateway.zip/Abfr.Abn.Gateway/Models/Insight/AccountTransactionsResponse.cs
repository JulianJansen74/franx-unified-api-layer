using System.Text.Json.Serialization;

namespace Abfr.Abn.Gateway.Models.Insight;

public sealed record AccountTransactionsResponse(
    [property: JsonPropertyName("accountNumber")]
    string AccountNumber,
    [property: JsonPropertyName("nextPageKey")]
    string? NextPageKey,
    [property: JsonPropertyName("transactions")]
    IReadOnlyCollection<AccountTransaction> Transactions);

public sealed record AccountTransaction(
    [property: JsonPropertyName("transactionId")]
    string? TransactionId,
    [property: JsonPropertyName("mutationCode")]
    string MutationCode,
    [property: JsonPropertyName("descriptionLines")]
    IReadOnlyCollection<string> DescriptionLines,
    [property: JsonPropertyName("transactionTimestamp")]
    string TransactionTimestamp,
    [property: JsonPropertyName("bookDate")]
    DateOnly BookDate,
    [property: JsonPropertyName("balanceAfterMutation")]
    decimal BalanceAfterMutation,
    [property: JsonPropertyName("counterPartyAccountNumber")]
    string? CounterPartyAccountNumber,
    [property: JsonPropertyName("counterPartyName")]
    string? CounterPartyName,
    [property: JsonPropertyName("amount")]
    decimal Amount,
    [property: JsonPropertyName("currency")]
    string Currency,
    [property: JsonPropertyName("status")]
    string Status);
