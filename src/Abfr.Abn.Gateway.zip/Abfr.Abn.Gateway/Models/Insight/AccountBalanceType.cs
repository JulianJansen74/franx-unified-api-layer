namespace Abfr.Abn.Gateway.Models.Insight;

public static class AccountBalanceType
{
    public const string BookBalance = "BOOKBALANCE";
    public const string ValueBalance = "VALUEBALANCE";
    public const string BookBalanceIncludingReservation = "BOOKBALANCEINCLUDINGRESERVATION";
}
