using System.Text.Json.Serialization;

namespace Abfr.Abn.Gateway.Models.Insight;

public sealed record AccountDetailsResponse(
    [property: JsonPropertyName("accountNumber")]
    string AccountNumber,
    [property: JsonPropertyName("currency")]
    string? Currency,
    [property: JsonPropertyName("accountHolderName")]
    string? AccountHolderName);
