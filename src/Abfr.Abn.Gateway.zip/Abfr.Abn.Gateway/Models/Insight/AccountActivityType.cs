namespace Abfr.Abn.Gateway.Models.Insight;

public static class AccountActivityType
{
    public const string Booked = "BOOKED";
    public const string Reservation = "RESERVATION";
}
