using System.Text.Json.Serialization;

namespace Abfr.Abn.Gateway.Models.Insight;

public sealed record AccountActivitiesResponse(
    [property: JsonPropertyName("accountNumber")]
    string AccountNumber,
    [property: JsonPropertyName("nextPageKey")]
    string? NextPageKey,
    [property: JsonPropertyName("activities")]
    AccountActivities Activities);

public sealed record AccountActivities(
    [property: JsonPropertyName("booked")]
    IReadOnlyCollection<BookedActivity>? Booked,
    [property: JsonPropertyName("reservations")]
    IReadOnlyCollection<ReservationActivity>? Reservations);

public sealed record BookedActivity(
    [property: JsonPropertyName("id")]
    string? Id,
    [property: JsonPropertyName("mutationCode")]
    string? MutationCode,
    [property: JsonPropertyName("descriptionLines")]
    IReadOnlyCollection<string> DescriptionLines,
    [property: JsonPropertyName("timestamp")]
    DateTimeOffset Timestamp,
    [property: JsonPropertyName("bookDate")]
    DateOnly? BookDate,
    [property: JsonPropertyName("amount")]
    decimal Amount,
    [property: JsonPropertyName("creditDebitIndicator")]
    string CreditDebitIndicator,
    [property: JsonPropertyName("currency")]
    string? Currency,
    [property: JsonPropertyName("balanceAfterMutation")]
    decimal? BalanceAfterMutation,
    [property: JsonPropertyName("balanceCreditDebitIndicator")]
    string? BalanceCreditDebitIndicator,
    [property: JsonPropertyName("counterPartyAccountNumber")]
    string? CounterPartyAccountNumber,
    [property: JsonPropertyName("counterPartyName")]
    string? CounterPartyName,
    [property: JsonPropertyName("status")]
    string Status);

public sealed record ReservationActivity(
    [property: JsonPropertyName("id")]
    string? Id,
    [property: JsonPropertyName("descriptionLines")]
    IReadOnlyCollection<string> DescriptionLines,
    [property: JsonPropertyName("timestamp")]
    DateTimeOffset Timestamp,
    [property: JsonPropertyName("lastUpdateDateTime")]
    DateTimeOffset? LastUpdateDateTime,
    [property: JsonPropertyName("amount")]
    decimal Amount,
    [property: JsonPropertyName("creditDebitIndicator")]
    string CreditDebitIndicator,
    [property: JsonPropertyName("currency")]
    string? Currency,
    [property: JsonPropertyName("expirationDate")]
    DateOnly? ExpirationDate,
    [property: JsonPropertyName("counterPartyName")]
    string? CounterPartyName,
    [property: JsonPropertyName("status")]
    string Status);
