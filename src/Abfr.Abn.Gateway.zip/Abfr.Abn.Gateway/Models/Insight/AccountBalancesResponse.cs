using System.Text.Json.Serialization;

namespace Abfr.Abn.Gateway.Models.Insight;

public sealed record AccountBalancesResponse(
    [property: JsonPropertyName("accountNumber")]
    string AccountNumber,
    [property: JsonPropertyName("balanceType")]
    string? BalanceType,
    [property: JsonPropertyName("amount")]
    decimal? Amount,
    [property: JsonPropertyName("currency")]
    string? Currency,
    [property: JsonPropertyName("creditDebitIndicator")]
    string? CreditDebitIndicator);
