namespace Abfr.Abn.Gateway.Http;

public static class AbnAmroHttpRequestOptions
{
    public static HttpRequestOptionsKey<string> AccountNumberForConsent { get; } =
        new("Abfr.Abn.AccountNumberForConsent");
}
