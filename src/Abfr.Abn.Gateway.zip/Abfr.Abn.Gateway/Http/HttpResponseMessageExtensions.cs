using System.Net.Http.Json;
using Abfr.Abn.Gateway.Exceptions;

namespace Abfr.Abn.Gateway.Http;

internal static class HttpResponseMessageExtensions
{
    public static async Task<T> ReadRequiredJsonAsync<T>(
        this HttpResponseMessage response,
        CancellationToken cancellationToken)
    {
        if (!response.IsSuccessStatusCode)
        {
            var body = await response.Content.ReadAsStringAsync(cancellationToken);
            throw new AbnAmroApiException(
                response.StatusCode,
                body,
                $"ABN AMRO API request failed with status code {(int)response.StatusCode}.");
        }

        var result = await response.Content.ReadFromJsonAsync<T>(cancellationToken);
        return result ?? throw new InvalidOperationException("ABN AMRO API response body is empty.");
    }
}
