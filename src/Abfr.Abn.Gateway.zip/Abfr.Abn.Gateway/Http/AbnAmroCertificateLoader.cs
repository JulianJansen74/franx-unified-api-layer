using System.Security.Cryptography.X509Certificates;
using Abfr.Abn.Gateway.Configuration;
using Microsoft.Extensions.Options;

namespace Abfr.Abn.Gateway.Http;

public sealed class AbnAmroCertificateLoader(IOptions<AbnAmroOptions> options)
{
    private readonly AbnAmroClientCertificateOptions _certificateOptions = options.Value.ClientCertificate;

    public X509Certificate2 Load()
    {
        var certificatePath = ResolvePath(_certificateOptions.CertificatePath);
        var privateKeyPath = ResolvePath(_certificateOptions.PrivateKeyPath);

        if (!File.Exists(certificatePath))
        {
            throw new FileNotFoundException("ABN AMRO client certificate file was not found.", certificatePath);
        }

        if (!File.Exists(privateKeyPath))
        {
            throw new FileNotFoundException("ABN AMRO client certificate private key file was not found.", privateKeyPath);
        }

        using var fromPem = X509Certificate2.CreateFromPemFile(certificatePath, privateKeyPath);
        var pkcs12 = fromPem.Export(X509ContentType.Pkcs12);
        return X509CertificateLoader.LoadPkcs12(
            pkcs12,
            password: null,
            X509KeyStorageFlags.Exportable | X509KeyStorageFlags.UserKeySet | X509KeyStorageFlags.PersistKeySet);
    }

    private static string ResolvePath(string path) =>
        Path.IsPathRooted(path)
            ? path
            : Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, path));
}
