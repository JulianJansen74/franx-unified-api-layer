using System.ComponentModel.DataAnnotations;

namespace Abfr.Abn.Gateway.Configuration;

public sealed class AbnAmroClientCertificateOptions
{
    [Required]
    public required string CertificatePath { get; init; }

    [Required]
    public required string PrivateKeyPath { get; init; }
}
