namespace Abfr.Abn.Gateway.Configuration;

public static class AbnAmroScopes
{
    public const string BusinessAccountInsight =
        "account:details:read account:balance:read account:transaction:read";

    public const string BusinessAccountPayment =
        "payment:unsigned:write payment:status:read";
}
