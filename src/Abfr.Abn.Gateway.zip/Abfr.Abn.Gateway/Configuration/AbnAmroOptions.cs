using System.ComponentModel.DataAnnotations;

namespace Abfr.Abn.Gateway.Configuration;

public sealed class AbnAmroOptions
{
    [Required]
    public required Uri BaseUrl { get; init; }

    [Required]
    public required Uri AuthUrl { get; init; }

    [Required]
    public required AbnAmroClientCertificateOptions ClientCertificate { get; init; }

    public TimeSpan TokenRefreshSkew { get; init; } = TimeSpan.FromSeconds(30);
}
