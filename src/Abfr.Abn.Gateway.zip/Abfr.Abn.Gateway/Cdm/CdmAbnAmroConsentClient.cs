using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Abfr.Abn.Gateway.Authentication;
using Microsoft.Extensions.Logging;

namespace Abfr.Abn.Gateway.Cdm
{
    public sealed class CdmAbnAmroConsentClient(HttpClient httpClient, ILogger<CdmAbnAmroConsentClient> logger)
        : IAbnAmroCdmConsentClient
    {
        private const string AbnConsentPath = "api/v1/corporate-info/abn-consent";

        private static readonly JsonSerializerOptions SerializerOptions = new()
        {
            PropertyNameCaseInsensitive = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        public async Task<AbnAmroAccountConsent> GetConsentAsync(string accountNumber, CancellationToken cancellationToken)
        {
            var path = $"{AbnConsentPath}?accountNumber={Uri.EscapeDataString(accountNumber)}";
            logger.LogInformation("Request ABN consent from CDM ({Path})", path);

            using var response = await httpClient.GetAsync(path, cancellationToken);

            logger.LogInformation("ABN consent CDM response status {StatusCode}", response.StatusCode);

            if (!response.IsSuccessStatusCode)
            {
                var cdmError = await TryReadCdmErrorAsync(response, cancellationToken);
                var message = cdmError is null
                    ? $"CDM consent request failed with status {(int)response.StatusCode} ({response.StatusCode})."
                    : $"CDM consent request failed: {cdmError.Key} - {cdmError.Data}";

                throw new HttpRequestException(message, null, response.StatusCode);
            }

            var body = await response.Content.ReadFromJsonAsync<CdmAbnConsentResponse>(SerializerOptions, cancellationToken)
                       ?? throw new InvalidOperationException("CDM ABN consent response body is empty.");

            return new AbnAmroAccountConsent(body.ClientId, body.ApiKey);
        }

        private static async Task<CdmErrorItem?> TryReadCdmErrorAsync(HttpResponseMessage response, CancellationToken cancellationToken)
        {
            try
            {
                var payload = await response.Content.ReadFromJsonAsync<CdmErrorResponse>(SerializerOptions, cancellationToken);
                return payload?.Errors?.FirstOrDefault();
            }
            catch
            {
                // If parsing fails, fallback to generic message
                return null;
            }
        }

        private sealed class CdmAbnConsentResponse
        {
            public string ClientId { get; init; } = "";
            public string ApiKey { get; init; } = "";
            public string? Status { get; init; }
        }

        private sealed class CdmErrorResponse
        {
            public List<CdmErrorItem>? Errors { get; init; }
        }

        private sealed class CdmErrorItem
        {
            public string? Key { get; init; }
            public string? Data { get; init; }
        }
    }
}
