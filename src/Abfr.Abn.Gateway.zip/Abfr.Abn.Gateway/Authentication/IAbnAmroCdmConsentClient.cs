namespace Abfr.Abn.Gateway.Authentication;

public interface IAbnAmroCdmConsentClient
{
    Task<AbnAmroAccountConsent> GetConsentAsync(string accountNumber, CancellationToken cancellationToken);
}
