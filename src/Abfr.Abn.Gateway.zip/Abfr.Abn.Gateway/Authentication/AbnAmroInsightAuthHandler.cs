namespace Abfr.Abn.Gateway.Authentication;

public sealed class AbnAmroInsightAuthHandler(
    AbnAmroTokenProvider tokenProvider,
    IAbnAmroCdmConsentClient cdmConsentClient) : AbnAmroAuthHandler(tokenProvider, cdmConsentClient)
{
    protected override AbnAmroScopeGroup ScopeGroup => AbnAmroScopeGroup.Insight;
}
