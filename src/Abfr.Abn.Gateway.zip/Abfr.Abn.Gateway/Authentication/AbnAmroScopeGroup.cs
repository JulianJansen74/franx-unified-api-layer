namespace Abfr.Abn.Gateway.Authentication;

public enum AbnAmroScopeGroup
{
    Insight,
    Payment
}
