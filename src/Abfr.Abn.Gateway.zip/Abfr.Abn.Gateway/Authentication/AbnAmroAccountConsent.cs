namespace Abfr.Abn.Gateway.Authentication;

public sealed record AbnAmroAccountConsent(string ClientId, string ApiKey);
