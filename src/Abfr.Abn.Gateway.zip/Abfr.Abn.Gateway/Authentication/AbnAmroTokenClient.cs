using System.Net.Http.Json;

namespace Abfr.Abn.Gateway.Authentication;

public sealed class AbnAmroTokenClient(HttpClient httpClient)
{
    public async Task<AbnAmroTokenResponse> RequestAccessTokenAsync(
        string scope,
        string clientId,
        CancellationToken cancellationToken)
    {
        using var content = new FormUrlEncodedContent([
            new KeyValuePair<string, string>("grant_type", "client_credentials"),
            new KeyValuePair<string, string>("client_id", clientId),
            new KeyValuePair<string, string>("scope", scope)
        ]);

        using var response = await httpClient.PostAsync(AbnConstants.Paths.Token, content, cancellationToken);

        response.EnsureSuccessStatusCode();

        var tokenResponse = await response.Content.ReadFromJsonAsync<AbnAmroTokenResponse>(cancellationToken);
        return tokenResponse ?? throw new InvalidOperationException("ABN AMRO token response body is empty.");
    }
}
