using System.Net.Http.Headers;
using Abfr.Abn.Gateway.Http;

namespace Abfr.Abn.Gateway.Authentication;

public abstract class AbnAmroAuthHandler(
    AbnAmroTokenProvider tokenProvider,
    IAbnAmroCdmConsentClient cdmConsentClient) : DelegatingHandler
{
    protected abstract AbnAmroScopeGroup ScopeGroup { get; }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        ConfigureRequest(request);

        if (!request.Options.TryGetValue(AbnAmroHttpRequestOptions.AccountNumberForConsent, out var accountNumber) ||
            string.IsNullOrWhiteSpace(accountNumber))
        {
            throw new InvalidOperationException(
                "Account number for ABN AMRO consent is missing; set AbnAmroHttpRequestOptions.AccountNumberForConsent on the outbound HttpRequestMessage.");
        }

        var consent = await cdmConsentClient.GetConsentAsync(accountNumber, cancellationToken);
        
        var token = await tokenProvider.GetAccessTokenAsync(ScopeGroup, consent.ClientId, cancellationToken);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

        request.Headers.Remove(AbnConstants.ApiKeyHeaderName);
        request.Headers.TryAddWithoutValidation(AbnConstants.ApiKeyHeaderName, consent.ApiKey);

        return await base.SendAsync(request, cancellationToken);
    }

    protected virtual void ConfigureRequest(HttpRequestMessage request)
    {
    }
}
