namespace Abfr.Abn.Gateway.Authentication;

public sealed class AbnAmroPaymentAuthHandler(
    AbnAmroTokenProvider tokenProvider,
    IAbnAmroCdmConsentClient cdmConsentClient) : AbnAmroAuthHandler(tokenProvider, cdmConsentClient)
{
    protected override AbnAmroScopeGroup ScopeGroup => AbnAmroScopeGroup.Payment;

    protected override void ConfigureRequest(HttpRequestMessage request)
    {
        if (request.Headers.Contains(AbnConstants.RequestIdHeaderName))
        {
            return;
        }

        request.Headers.TryAddWithoutValidation(AbnConstants.RequestIdHeaderName, Guid.NewGuid().ToString());
    }
}
