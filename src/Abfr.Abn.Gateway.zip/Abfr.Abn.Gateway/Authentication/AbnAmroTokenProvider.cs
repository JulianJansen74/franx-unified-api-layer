using System.Collections.Concurrent;
using Abfr.Abn.Gateway.Configuration;
using Microsoft.Extensions.Options;

namespace Abfr.Abn.Gateway.Authentication;

public sealed class AbnAmroTokenProvider(AbnAmroTokenClient tokenClient, IOptions<AbnAmroOptions> options)
{
    private readonly ConcurrentDictionary<CredentialCacheKey, TokenCacheEntry> _cache = [];
    private readonly TimeSpan _refreshSkew = options.Value.TokenRefreshSkew;

    public async Task<string> GetAccessTokenAsync(
        AbnAmroScopeGroup scopeGroup,
        string clientId,
        CancellationToken cancellationToken)
    {
        var cacheKey = new CredentialCacheKey(scopeGroup, clientId);
        var cacheEntry = _cache.GetOrAdd(cacheKey, _ => new TokenCacheEntry());
        var cachedToken = cacheEntry.Token;

        if (IsUsable(cachedToken))
        {
            return cachedToken.Token;
        }

        await cacheEntry.Lock.WaitAsync(cancellationToken);
        try
        {
            cachedToken = cacheEntry.Token;
            if (IsUsable(cachedToken))
            {
                return cachedToken.Token;
            }

            var tokenResponse = await tokenClient.RequestAccessTokenAsync(GetScope(scopeGroup), clientId, cancellationToken);
            var expiresAt = DateTimeOffset.UtcNow.AddSeconds(tokenResponse.ExpiresIn);
            var token = new AbnAmroAccessToken(tokenResponse.AccessToken, expiresAt);

            cacheEntry.Token = token;

            return token.Token;
        }
        finally
        {
            cacheEntry.Lock.Release();
        }
    }

    private bool IsUsable(AbnAmroAccessToken? token) =>
        token is not null && DateTimeOffset.UtcNow.Add(_refreshSkew) < token.ExpiresAt;

    private static string GetScope(AbnAmroScopeGroup scopeGroup) =>
        scopeGroup switch
        {
            AbnAmroScopeGroup.Insight => AbnAmroScopes.BusinessAccountInsight,
            AbnAmroScopeGroup.Payment => AbnAmroScopes.BusinessAccountPayment,
            _ => throw new ArgumentOutOfRangeException(nameof(scopeGroup), scopeGroup, null)
        };

    private sealed class TokenCacheEntry
    {
        public SemaphoreSlim Lock { get; } = new(1, 1);

        public AbnAmroAccessToken? Token { get; set; }
    }

    private readonly record struct CredentialCacheKey(AbnAmroScopeGroup ScopeGroup, string ClientId);
}
