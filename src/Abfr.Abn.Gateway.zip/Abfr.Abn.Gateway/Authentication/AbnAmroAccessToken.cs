namespace Abfr.Abn.Gateway.Authentication;

public sealed record AbnAmroAccessToken(string Token, DateTimeOffset ExpiresAt);
