using System.Net;

namespace Abfr.Abn.Gateway.Exceptions;

public sealed class AbnAmroApiException(
    HttpStatusCode statusCode,
    string responseBody,
    string message) : HttpRequestException(message, null, statusCode)
{
    public string ResponseBody { get; } = responseBody;
}
