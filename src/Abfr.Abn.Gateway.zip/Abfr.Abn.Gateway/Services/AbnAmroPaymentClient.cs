using System.Net.Http.Json;
using Abfr.Abn.Gateway.Http;
using Abfr.Abn.Gateway.Models.Payment;

namespace Abfr.Abn.Gateway.Services;

public sealed class AbnAmroPaymentClient(HttpClient httpClient)
{
    public async Task<InitiatePaymentResponse> InitiatePaymentAsync(
        string accountNumber,
        InitiatePaymentRequest request,
        CancellationToken cancellationToken)
    {
        using var msg = new HttpRequestMessage(HttpMethod.Post, AbnConstants.Paths.Payments)
        {
            Content = JsonContent.Create(request)
        };
        SetConsentAccountNumber(msg, accountNumber);

        using var response = await httpClient.SendAsync(msg, cancellationToken);

        return await response.ReadRequiredJsonAsync<InitiatePaymentResponse>(cancellationToken);
    }

    public async Task<PaymentStatusResponse> GetPaymentStatusAsync(
        string accountNumber,
        string paymentId,
        CancellationToken cancellationToken)
    {
        var path = string.Format(AbnConstants.Paths.PaymentStatus, Uri.EscapeDataString(paymentId));

        using var msg = new HttpRequestMessage(HttpMethod.Get, path);
        SetConsentAccountNumber(msg, accountNumber);

        using var response = await httpClient.SendAsync(msg, cancellationToken);

        return await response.ReadRequiredJsonAsync<PaymentStatusResponse>(cancellationToken);
    }

    private static void SetConsentAccountNumber(HttpRequestMessage request, string accountNumber) =>
        request.Options.Set(AbnAmroHttpRequestOptions.AccountNumberForConsent, accountNumber);
}
