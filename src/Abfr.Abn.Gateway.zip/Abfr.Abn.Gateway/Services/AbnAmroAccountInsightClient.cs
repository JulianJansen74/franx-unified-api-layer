using Abfr.Abn.Gateway.Http;
using Abfr.Abn.Gateway.Models.Insight;

namespace Abfr.Abn.Gateway.Services;

public sealed class AbnAmroAccountInsightClient(HttpClient httpClient)
{
    public async Task<AccountDetailsResponse> GetAccountDetailsAsync(string iban, CancellationToken cancellationToken)
    {
        var path = string.Format(AbnConstants.Paths.AccountDetails, Uri.EscapeDataString(iban));
        using var request = new HttpRequestMessage(HttpMethod.Get, path);
        SetConsentAccountNumber(request, iban);

        using var response = await httpClient.SendAsync(request, cancellationToken);

        return await response.ReadRequiredJsonAsync<AccountDetailsResponse>(cancellationToken);
    }

    public async Task<AccountBalancesResponse> GetAccountBalancesAsync(
        string iban,
        CancellationToken cancellationToken,
        string? balanceType = null)
    {
        var requestPath = AddQueryString(
            string.Format(AbnConstants.Paths.AccountBalances, Uri.EscapeDataString(iban)),
            ("balanceType", balanceType));

        using var request = new HttpRequestMessage(HttpMethod.Get, requestPath);
        SetConsentAccountNumber(request, iban);

        using var response = await httpClient.SendAsync(request, cancellationToken);

        return await response.ReadRequiredJsonAsync<AccountBalancesResponse>(cancellationToken);
    }

    public async Task<AccountTransactionsResponse> GetAccountTransactionsAsync(
        string iban,
        CancellationToken cancellationToken,
        DateOnly? bookDateFrom = null,
        DateOnly? bookDateTo = null,
        string? nextPageKey = null)
    {
        var requestPath = AddQueryString(
            string.Format(AbnConstants.Paths.AccountTransactions, Uri.EscapeDataString(iban)),
            ("bookDateFrom", FormatDate(bookDateFrom)),
            ("bookDateTo", FormatDate(bookDateTo)),
            ("nextPageKey", nextPageKey));

        using var request = new HttpRequestMessage(HttpMethod.Get, requestPath);
        SetConsentAccountNumber(request, iban);

        using var response = await httpClient.SendAsync(request, cancellationToken);

        return await response.ReadRequiredJsonAsync<AccountTransactionsResponse>(cancellationToken);
    }

    public async Task<AccountActivitiesResponse> GetAccountActivitiesAsync(
        string iban,
        CancellationToken cancellationToken,
        DateOnly? dateFrom = null,
        DateOnly? dateTo = null,
        string? nextPageKey = null,
        string? activityType = null,
        string? status = null)
    {
        var requestPath = AddQueryString(
            string.Format(AbnConstants.Paths.AccountActivities, Uri.EscapeDataString(iban)),
            ("dateFrom", FormatDate(dateFrom)),
            ("dateTo", FormatDate(dateTo)),
            ("nextPageKey", nextPageKey),
            ("activityType", activityType),
            ("status", status));

        using var request = new HttpRequestMessage(HttpMethod.Get, requestPath);
        SetConsentAccountNumber(request, iban);

        using var response = await httpClient.SendAsync(request, cancellationToken);

        return await response.ReadRequiredJsonAsync<AccountActivitiesResponse>(cancellationToken);
    }

    private static void SetConsentAccountNumber(HttpRequestMessage request, string accountNumber) =>
        request.Options.Set(AbnAmroHttpRequestOptions.AccountNumberForConsent, accountNumber);

    private static string? FormatDate(DateOnly? date) =>
        date?.ToString("yyyy-MM-dd");

    private static string AddQueryString(string path, params (string Name, string? Value)[] parameters)
    {
        var queryParameters = parameters
            .Where(parameter => !string.IsNullOrWhiteSpace(parameter.Value))
            .Select(parameter =>
                $"{Uri.EscapeDataString(parameter.Name)}={Uri.EscapeDataString(parameter.Value!)}")
            .ToArray();

        return queryParameters.Length == 0 ? path : $"{path}?{string.Join('&', queryParameters)}";
    }
}
