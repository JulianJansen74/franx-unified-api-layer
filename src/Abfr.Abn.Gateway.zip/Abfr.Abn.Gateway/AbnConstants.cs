﻿namespace Abfr.Abn.Gateway;

public static class AbnConstants
{
    public const string AuthHttpClientName = "AbnAmroAuth";
    public const string ApiKeyHeaderName = "API-Key";
    public const string RequestIdHeaderName = "X-Request-Id";
    public const string CertificateFolderName = "Certificates";

    public static class Paths
    {
        public const string Token = "as/token.oauth2";
        public const string AccountDetails = "v1/accounts/{0}/details";
        public const string AccountBalances = "v1/accounts/{0}/balances";
        public const string AccountTransactions = "v1/accounts/{0}/transactions";
        public const string AccountActivities = "v1/accounts/{0}/activities";
        public const string Payments = "v1/customer-api/payments";
        public const string PaymentStatus = "v1/customer-api/payments/{0}/status";
    }
}
