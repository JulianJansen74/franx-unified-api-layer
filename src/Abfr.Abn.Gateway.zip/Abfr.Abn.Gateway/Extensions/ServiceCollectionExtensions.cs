using System.Security.Cryptography.X509Certificates;
using Abfr.Abn.Gateway.Authentication;
using Abfr.Abn.Gateway.Configuration;
using Abfr.Abn.Gateway.Http;
using Abfr.Abn.Gateway.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Abfr.Abn.Gateway.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddAbnAmroGateway(
        this IServiceCollection services,
        IConfiguration configuration,
        string sectionName = "AbnAmro")
    {
        services
            .AddOptions<AbnAmroOptions>()
            .Bind(configuration.GetSection(sectionName))
            .ValidateDataAnnotations()
            .ValidateOnStart();

        services.AddSingleton<AbnAmroCertificateLoader>();
        services.AddSingleton(sp =>
        {
            var httpClientFactory = sp.GetRequiredService<IHttpClientFactory>();

            return new AbnAmroTokenClient(
                httpClientFactory.CreateClient(AbnConstants.AuthHttpClientName));
        });
        services.AddSingleton<AbnAmroTokenProvider>();

        services.AddTransient<AbnAmroInsightAuthHandler>();
        services.AddTransient<AbnAmroPaymentAuthHandler>();

        services.AddHttpClient(AbnConstants.AuthHttpClientName, (sp, client) =>
            {
                var options = sp.GetRequiredService<IOptions<AbnAmroOptions>>().Value;
                client.BaseAddress = options.AuthUrl;
            })
            .ConfigurePrimaryHttpMessageHandler(sp =>
            {
                var certificate = sp.GetRequiredService<AbnAmroCertificateLoader>().Load();

                return new SocketsHttpHandler
                {
                    SslOptions =
                    {
                        ClientCertificates = new X509CertificateCollection { certificate }
                    }
                };
            });

        services.AddHttpClient<AbnAmroAccountInsightClient>((sp, client) =>
            {
                var options = sp.GetRequiredService<IOptions<AbnAmroOptions>>().Value;
                client.BaseAddress = options.BaseUrl;
            })
            .AddHttpMessageHandler<AbnAmroInsightAuthHandler>();

        services.AddHttpClient<AbnAmroPaymentClient>((sp, client) =>
            {
                var options = sp.GetRequiredService<IOptions<AbnAmroOptions>>().Value;
                client.BaseAddress = options.BaseUrl;
            })
            .AddHttpMessageHandler<AbnAmroPaymentAuthHandler>();

        return services;
    }
}
