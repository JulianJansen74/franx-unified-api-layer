﻿#nullable enable
using Abf.Account.AccountApiData.Entities;

namespace Abf.Account.Repositories;

public interface IBackofficeRepository
{
    Task<IReadOnlyCollection<Backoffice>> GetAllAsync(CancellationToken cancellationToken);
}
