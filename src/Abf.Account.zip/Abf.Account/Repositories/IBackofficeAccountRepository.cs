﻿#nullable enable
using Abf.Account.AccountApiData.Entities;
using Abf.Account.Common;

namespace Abf.Account.Repositories;

public interface IBackofficeAccountRepository
{
    Task<BackofficeAccount?> GetByAccountNumberAsync(string accountNumber, CancellationToken cancellationToken);
    Task<IReadOnlyCollection<BackofficeAccount>> GetByBackofficeIdAsync(int backofficeId);
    Task<BackofficeAccount> CreateAsync(BackofficeAccount account);
    Task<BackofficeAccount> UpdateAsync(BackofficeAccount account);
    Task DeleteAsync(string accountNumber, int backofficeId);
    Task<IReadOnlyCollection<BackofficeAccount>> GetByAccountNumbersAsync(IEnumerable<string> accountNumbers, CancellationToken cancellationToken);
    Task CreateManyAsync(IEnumerable<string> accountNumbers, BackofficeName backofficeName, CancellationToken cancellationToken);
}
