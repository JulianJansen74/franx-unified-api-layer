﻿using System.Net;
using Abf.Account.Common.Exceptions;

namespace Abf.Account.Exceptions
{
    public class ConflictException : Exception, IAppException
    {
        public string ErrorKey => nameof(ConflictException);
        public string Detail => Message;
        public HttpStatusCode HttpStatusCode => HttpStatusCode.Conflict;
    }
}
