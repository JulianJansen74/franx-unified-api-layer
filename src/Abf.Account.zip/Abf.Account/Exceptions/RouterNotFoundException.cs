﻿using System.Net;
using Abf.Account.Common.Exceptions;

namespace Abf.Account.Exceptions;

public class RouterNotFoundException : Exception, IAppException
{
    public RouterNotFoundException(string message) : base(message) { }

    public RouterNotFoundException(string message, Exception innerException) : base(message, innerException) { }
    public string ErrorKey => nameof(RouterNotFoundException);
    public string Detail => Message;
    public HttpStatusCode HttpStatusCode => HttpStatusCode.BadRequest;
}
