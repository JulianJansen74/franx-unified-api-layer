﻿using System.Net;
using Abf.Account.Common.Exceptions;

namespace Abf.Account.Exceptions
{
    public class DuplicateContractException() : Exception("Duplicated contract request."), IAppException
    {
        public string ErrorKey => nameof(DuplicateContractException);
        public string Detail => Message;
        public HttpStatusCode HttpStatusCode => HttpStatusCode.Conflict;
    }
}
