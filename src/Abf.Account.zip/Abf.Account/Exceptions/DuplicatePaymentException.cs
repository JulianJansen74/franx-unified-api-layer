﻿using System.Net;
using Abf.Account.Common.Exceptions;

namespace Abf.Account.Exceptions;

public class DuplicatePaymentException(string transactionId)
    : Exception($"Duplicate transfer for transactionId {transactionId}"), IAppException
{
    public string ErrorKey => nameof(DuplicatePaymentException);
    public string Detail => Message;
    public HttpStatusCode HttpStatusCode => HttpStatusCode.Conflict;
}
