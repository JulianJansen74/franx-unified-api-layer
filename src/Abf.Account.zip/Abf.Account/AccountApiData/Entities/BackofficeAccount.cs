﻿namespace Abf.Account.AccountApiData.Entities;

public class BackofficeAccount
{
    public string AccountNumber { get; set; } = string.Empty;
    public int BackofficeId { get; set; }
    public AccountStatus Status { get; set; } = AccountStatus.Active;
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }

    // Navigation property
    public virtual Backoffice Backoffice { get; set; } = null!;
}
