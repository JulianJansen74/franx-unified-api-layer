namespace Abf.Account.AccountApiData.Entities;

public enum AccountStatus
{
    Active,
    Closed
}
