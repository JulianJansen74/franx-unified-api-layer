namespace Abf.Account.AccountApiData.Entities;

public class Backoffice
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }

    // Navigation property
    public virtual ICollection<BackofficeAccount> Accounts { get; set; } = new HashSet<BackofficeAccount>();
}
