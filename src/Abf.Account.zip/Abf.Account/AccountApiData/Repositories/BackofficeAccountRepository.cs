#nullable enable
using Abf.Account.AccountApiData.Entities;
using Abf.Account.Common;
using Abf.Account.Repositories;
using Microsoft.EntityFrameworkCore;

namespace Abf.Account.AccountApiData.Repositories;

public class BackofficeAccountRepository(AccountDbContext dbContext, AppClock appClock) : IBackofficeAccountRepository
{
    public async Task<BackofficeAccount?> GetByAccountNumberAsync(string accountNumber,
        CancellationToken cancellationToken)
    {
        return await dbContext.BackofficeAccounts
            .FirstOrDefaultAsync(a => a.AccountNumber == accountNumber, cancellationToken);
    }

    public async Task<IReadOnlyCollection<BackofficeAccount>> GetByBackofficeIdAsync(int backofficeId)
    {
        return await dbContext.BackofficeAccounts
            .Where(a => a.BackofficeId == backofficeId)
            .OrderBy(a => a.AccountNumber)
            .ToListAsync();
    }

    public async Task<IReadOnlyCollection<BackofficeAccount>> GetByAccountNumbersAsync(
        IEnumerable<string> accountNumbers, CancellationToken cancellationToken)
    {
        var accountNumberList = accountNumbers?.Where(x => !string.IsNullOrEmpty(x)).Distinct().ToList() ??
                                new List<string>();
        if (accountNumberList.Count == 0)
        {
            return [];
        }

        return await dbContext.BackofficeAccounts
            .AsNoTracking()
            .Where(a => accountNumberList.Contains(a.AccountNumber))
            .ToListAsync(cancellationToken);
    }

    public async Task<BackofficeAccount> CreateAsync(BackofficeAccount account)
    {
        var now = appClock.NowOffset;
        account.CreatedAt = now;
        account.UpdatedAt = now;

        dbContext.BackofficeAccounts.Add(account);
        await dbContext.SaveChangesAsync();

        return account;
    }

    public async Task<BackofficeAccount> UpdateAsync(BackofficeAccount account)
    {
        account.UpdatedAt = appClock.NowOffset;

        dbContext.BackofficeAccounts.Update(account);
        await dbContext.SaveChangesAsync();

        return account;
    }

    public async Task DeleteAsync(string accountNumber, int backofficeId)
    {
        var account = await dbContext.BackofficeAccounts
            .FirstOrDefaultAsync(a => a.AccountNumber == accountNumber && a.BackofficeId == backofficeId);

        if (account != null)
        {
            dbContext.BackofficeAccounts.Remove(account);
            await dbContext.SaveChangesAsync();
        }
    }

    public async Task CreateManyAsync(IEnumerable<string> accountNumbers, BackofficeName backofficeName,
        CancellationToken cancellationToken)
    {
        var now = appClock.NowOffset;
        var accounts = accountNumbers.Select(accountNumber => new BackofficeAccount
        {
            AccountNumber = accountNumber,
            BackofficeId = (int)backofficeName,
            Status = AccountStatus.Active,
            CreatedAt = now,
            UpdatedAt = now
        }).ToList();

        dbContext.BackofficeAccounts.AddRange(accounts);
        await dbContext.SaveChangesAsync(cancellationToken);
    }
}
