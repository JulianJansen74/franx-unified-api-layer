﻿#nullable enable
using Abf.Account.AccountApiData.Entities;
using Abf.Account.Repositories;
using Microsoft.EntityFrameworkCore;

namespace Abf.Account.AccountApiData.Repositories;

public class BackofficeRepository(AccountDbContext dbContext) : IBackofficeRepository
{
    public async Task<IReadOnlyCollection<Backoffice>> GetAllAsync(CancellationToken cancellationToken)
    {
        return await dbContext.Backoffices
            .OrderBy(b => b.Name)
            .ToListAsync(cancellationToken);
    }
}
