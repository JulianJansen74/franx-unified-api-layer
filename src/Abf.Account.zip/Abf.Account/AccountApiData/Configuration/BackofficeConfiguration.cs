using Abf.Account.AccountApiData.Entities;
using Abf.Account.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Abf.Account.AccountApiData.Configuration;

public class BackofficeConfiguration : IEntityTypeConfiguration<Backoffice>
{
    public void Configure(EntityTypeBuilder<Backoffice> builder)
    {
        builder.HasKey(e => e.Id)
            .HasName("PK_Backoffices");

        builder.ToTable("Backoffices", "dbo");

        builder.Property(e => e.Name)
            .IsRequired()
            .HasMaxLength(50)
            .IsUnicode(false);

        builder.Property(e => e.CreatedAt)
            .HasColumnType("datetimeoffset(7)")
            .HasDefaultValueSql(SqlConstants.DbNowOffset);

        builder.Property(e => e.UpdatedAt)
            .HasColumnType("datetimeoffset(7)");

        // Seed initial data using HasData
        var seedTime = new DateTimeOffset(2025, 7, 8, 11, 56, 18, TimeSpan.Zero).AddTicks(951715);
        builder.HasData(
            new Backoffice
            {
                Id = (int)BackofficeName.Matrix,
                Name = nameof(BackofficeName.Matrix),
                CreatedAt = seedTime,
                UpdatedAt = seedTime
            },
            new Backoffice
            {
                Id = (int)BackofficeName.Nolan,
                Name = nameof(BackofficeName.Nolan),
                CreatedAt = seedTime,
                UpdatedAt = seedTime
            }
        );
    }
}
