﻿using Abf.Account.AccountApiData.Entities;
using Abf.Account.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Abf.Account.AccountApiData.Configuration;

public class BackofficeAccountConfiguration : IEntityTypeConfiguration<BackofficeAccount>
{
    public void Configure(EntityTypeBuilder<BackofficeAccount> builder)
    {
        builder.HasKey(e => e.AccountNumber)
            .HasName("PK_BackofficeAccounts");

        builder.ToTable("BackofficeAccounts", "dbo");

        builder.Property(e => e.AccountNumber)
            .IsRequired()
            .HasMaxLength(50)
            .IsUnicode(false);
        
        builder.HasIndex(e => e.BackofficeId)
            .HasDatabaseName("IX_BackofficeAccounts_BackofficeId");

        builder.Property(e => e.CreatedAt)
            .HasColumnType("datetimeoffset(7)")
            .HasDefaultValueSql(SqlConstants.DbNowOffset);

        builder.Property(e => e.UpdatedAt)
            .HasColumnType("datetimeoffset(7)");

        builder.Property(e => e.Status)
            .HasConversion<string>()
            .HasMaxLength(10)
            .HasDefaultValue(AccountStatus.Active);

        builder.HasOne(e => e.Backoffice)
            .WithMany(e => e.Accounts)
            .HasForeignKey(e => e.BackofficeId)
            .OnDelete(DeleteBehavior.Restrict)
            .HasConstraintName("FK_BackofficeAccounts_Backoffices");
    }
}
