using Abf.Account.AccountApiData.Entities;
using Microsoft.EntityFrameworkCore;

namespace Abf.Account.AccountApiData
{
    public class AccountDbContext : DbContext
    {
        protected AccountDbContext()
        {
        }

        public AccountDbContext(DbContextOptions<AccountDbContext> options) : base(options)
        {
        }

        public virtual DbSet<Backoffice> Backoffices { get; set; }
        public virtual DbSet<BackofficeAccount> BackofficeAccounts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(AccountDbContext).Assembly);
        }
    }
}
