﻿using Abf.Account.Models.AccountBalance;
using Abf.Account.Service;

namespace Abf.Account.Routers;

public interface IAccountBalanceRouter : IRouter
{
    Task<AccountBalance[]?> GetAccountBalances(AccountBalanceRequest accountBalanceRequest, CancellationToken cancellationToken);
    Task<decimal?> GetAccountBalanceByValueDate(string accountNumber, DateTime valueDate);
}
