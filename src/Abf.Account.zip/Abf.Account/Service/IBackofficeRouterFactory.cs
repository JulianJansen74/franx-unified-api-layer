﻿#nullable enable

using Abf.Account.Common;

namespace Abf.Account.Service;

public interface IBackofficeRouterFactory
{
    T GetRouter<T>(BackofficeName backofficeName) where T : class, IRouter;

    T GetRouterFromHeader<T>() where T : class, IRouter;

    Task<T> GetRouterByAccountNumberWithFallbackAsync<T>(string? accountNumber,
        CancellationToken cancellationToken = default)
        where T : class, IRouter;

    Task<T> GetRouterByAccountNumbersWithFallbackAsync<T>(IEnumerable<string?> accountNumbers,
        CancellationToken cancellationToken = default)
        where T : class, IRouter;
}
