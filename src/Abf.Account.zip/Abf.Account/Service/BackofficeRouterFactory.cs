﻿#nullable enable
using System.Text.Json;
using Abf.Account.Common;
using Abf.Account.Common.Configurations;
using Abf.Account.Configuration;
using Abf.Account.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Abf.Account.Service;

public class BackofficeRouterFactory(
    IBackofficeAccountService backofficeAccountService,
    IHttpContextAccessor httpContextAccessor,
    IServiceProvider serviceProvider,
    IOptionsMonitor<ApplicationConfigurationsOptions> backofficeOptions,
    ILogger<BackofficeRouterFactory> logger)
    : IBackofficeRouterFactory
{
    private readonly BackofficeName _defaultBackoffice = backofficeOptions.CurrentValue.DefaultBackOffice;

    public T GetRouter<T>(BackofficeName backofficeName) where T : class, IRouter
    {
        try
        {
            var router = GetRouterByKey<T>(backofficeName);
            StoreBackofficeNameForLog(backofficeName);

            return router;
        }
        catch (RouterNotFoundException ex)
        {
            logger.LogError(ex, "Failed to get router of type {RouterType} for backoffice {Backoffice}",
                typeof(T).Name, backofficeName);
            throw;
        }
    }

    private void StoreBackofficeNameForLog(BackofficeName backofficeName)
    {
        if (httpContextAccessor.HttpContext != null)
        {
            httpContextAccessor.HttpContext.Items[Constants.BackofficeIdHeaderName] = backofficeName.ToString();
        }
    }

    private T GetRouterByKey<T>(BackofficeName backofficeName) where T : class, IRouter
    {
        try
        {
            var keyedService = serviceProvider.GetKeyedService<T>(backofficeName);
            if (keyedService == null)
            {
                throw new RouterNotFoundException(
                    $"Router of type {typeof(T).Name} not found for backoffice {backofficeName}");
            }

            return keyedService;
        }
        catch (Exception ex) when (ex is not RouterNotFoundException)
        {
            logger.LogError(ex, "Failed to get keyed router of type {RouterType} for backoffice {Backoffice}",
                typeof(T).Name, backofficeName);
            throw new RouterNotFoundException(
                $"Router of type {typeof(T).Name} not found for backoffice {backofficeName}", ex);
        }
    }

    public T GetRouterFromHeader<T>() where T : class, IRouter
    {
        var backoffice = backofficeAccountService.GetBackofficeFromHeader();

        logger.LogInformation("Request Routed to backoffice {Backoffice}, routed by header, requestPath: {requestPath}",
            backoffice, httpContextAccessor.HttpContext?.Request.Path.Value);

        return GetRouter<T>(backoffice);
    }

    public async Task<T> GetRouterByAccountNumberWithFallbackAsync<T>(string? accountNumber,
        CancellationToken cancellationToken = default)
        where T : class, IRouter
    {
        var backoffice =
            await backofficeAccountService.GetBackofficeForAccountWithFallbackAsync(accountNumber, cancellationToken);

        logger.LogInformation(
            "Request Routed to backoffice {Backoffice} for accountNumber {AccountNumber}, requestPath: {RequestPath}",
            backoffice, accountNumber, httpContextAccessor.HttpContext?.Request.Path.Value);

        return GetRouter<T>(backoffice);
    }

    public async Task<T> GetRouterByAccountNumbersWithFallbackAsync<T>(IEnumerable<string?> accountNumbers,
        CancellationToken cancellationToken = default)
        where T : class, IRouter
    {
        var accountsToCheck = accountNumbers.Where(x => !string.IsNullOrEmpty(x)).ToList();
        if (accountsToCheck.Count == 0)
        {
            logger.LogInformation(
                "Request Routed to backoffice {Backoffice}, No valid account numbers provided, requestPath: {RequestPath}",
                _defaultBackoffice, httpContextAccessor.HttpContext?.Request.Path.Value);

            return GetRouter<T>(_defaultBackoffice);
        }

        var backofficeMapping =
            await backofficeAccountService.GetBackofficeForAccountsAsync(accountsToCheck!, cancellationToken);

        var nonDefaultBackoffice = backofficeMapping.Values.FirstOrDefault(b => b != _defaultBackoffice);
        if (nonDefaultBackoffice != default)
        {
            logger.LogInformation(
                "Request Routed to backoffice {Backoffice} for accountNumbers {AccountNumber}, requestPath: {RequestPath}",
                nonDefaultBackoffice, JsonSerializer.Serialize(accountsToCheck, JsonSerializerOptions.Default),
                httpContextAccessor.HttpContext?.Request.Path.Value);

            return GetRouter<T>(nonDefaultBackoffice);
        }

        logger.LogInformation(
            "Request Routed to backoffice {Backoffice} for accountNumbers {AccountNumber}, requestPath: {RequestPath}",
            _defaultBackoffice, JsonSerializer.Serialize(accountsToCheck, JsonSerializerOptions.Default),
            httpContextAccessor.HttpContext?.Request.Path.Value);

        return GetRouter<T>(_defaultBackoffice);
    }
}
