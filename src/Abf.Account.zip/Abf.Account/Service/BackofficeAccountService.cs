﻿#nullable enable
using Abf.Account.AccountApiData.Entities;
using Abf.Account.Common;
using Abf.Account.Common.Configurations;
using Abf.Account.Configuration;
using Abf.Account.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Abf.Account.Service;

public class BackofficeAccountService(
    IBackofficeAccountRepository backofficeAccountRepository,
    IHttpContextAccessor httpContextAccessor,
    IOptionsMonitor<ApplicationConfigurationsOptions> backofficeOptions,
    ILogger<BackofficeAccountService> logger)
    : IBackofficeAccountService
{
    private readonly BackofficeName _defaultBackoffice = backofficeOptions.CurrentValue.DefaultBackOffice;

    public async Task<BackofficeName> GetBackofficeForAccountWithFallbackAsync(string? accountNumberFromBody,
        CancellationToken cancellationToken)
    {
        if (!string.IsNullOrEmpty(accountNumberFromBody))
        {
            var account =
                await backofficeAccountRepository.GetByAccountNumberAsync(accountNumberFromBody, cancellationToken);
            if (account != null)
            {
                if (account.Status == AccountStatus.Closed)
                {
                    logger.LogInformation("Account {AccountNumber} is closed, routing to default backoffice {BackofficeName}",
                        accountNumberFromBody, _defaultBackoffice);
                    return _defaultBackoffice;
                }

                return (BackofficeName)account.BackofficeId;
            }

            logger.LogWarning("Account not found in DB for account number {AccountNumber}", accountNumberFromBody);
        }

        var headerBackofficeId =
            httpContextAccessor.HttpContext?.Request.Headers[Constants.BackofficeIdHeaderName].FirstOrDefault();
        if (!string.IsNullOrEmpty(headerBackofficeId))
        {
            var isValidBackofficeName = Enum.TryParse<BackofficeName>(headerBackofficeId, out var backofficeName)
                                        && Enum.IsDefined(backofficeName);
            if (isValidBackofficeName)
            {
                return backofficeName;
            }

            logger.LogWarning("Header backoffice {HeaderBackofficeId} not found, falling back to default",
                headerBackofficeId);
        }

        logger.LogInformation("Using default backoffice {BackofficeName} for account {AccountNumber}",
            _defaultBackoffice.ToString(), accountNumberFromBody);

        return _defaultBackoffice;
    }

    public BackofficeName GetBackofficeFromHeader()
    {
        var headerBackofficeId =
            httpContextAccessor.HttpContext?.Request.Headers[Constants.BackofficeIdHeaderName].FirstOrDefault();
        if (!string.IsNullOrEmpty(headerBackofficeId))
        {
            var isValidBackofficeName = Enum.TryParse<BackofficeName>(headerBackofficeId, out var backofficeName)
                                        && Enum.IsDefined(backofficeName);
            if (isValidBackofficeName)
            {
                return backofficeName;
            }

            logger.LogWarning("Header backoffice {HeaderBackofficeId} not found, falling back to default",
                headerBackofficeId);
        }

        return _defaultBackoffice;
    }

    public async Task<Dictionary<string, BackofficeName>> GetBackofficeForAccountsAsync(
        IEnumerable<string>? accountNumbers, CancellationToken cancellationToken)
    {
        var result = new Dictionary<string, BackofficeName>();
        if (accountNumbers == null)
        {
            return result;
        }

        var accounts = accountNumbers.Where(x => !string.IsNullOrEmpty(x)).Distinct().ToList();
        if (accounts.Count == 0)
        {
            return result;
        }

        var dbAccounts = await backofficeAccountRepository.GetByAccountNumbersAsync(accounts, cancellationToken);
        var dbAccountDict = dbAccounts.ToDictionary(a => a.AccountNumber, a => a, StringComparer.OrdinalIgnoreCase);

        foreach (var acc in accounts)
        {
            var account = dbAccountDict.GetValueOrDefault(acc);
            BackofficeName backoffice;

            if (account != null)
            {
                backoffice = account.Status == AccountStatus.Closed ? _defaultBackoffice : (BackofficeName)account.BackofficeId;
            }
            else
            {
                backoffice = _defaultBackoffice;
            }

            result[acc] = backoffice;
        }

        return result;
    }

    public async Task UpdateAccountStatusToClosedAsync(string accountNumber, CancellationToken cancellationToken)
    {
        var account = await backofficeAccountRepository.GetByAccountNumberAsync(accountNumber, cancellationToken);
        if (account != null)
        {
            account.Status = AccountStatus.Closed;
            await backofficeAccountRepository.UpdateAsync(account);

            logger.LogInformation("Updated account {AccountNumber} status to Closed", accountNumber);
        }
        else
        {
            logger.LogInformation("Account {AccountNumber} not found in BackofficeAccounts table, skipping status update", accountNumber);
        }
    }
}
