﻿using Abf.Account.Common;

namespace Abf.Account.Service;

public interface IRouter
{
    BackofficeName BackOfficeName { get; }
}
