﻿using Abf.Account.Models.AccountBalance;

namespace Abf.Account.Service
{
    public interface IAccountBalanceService
    {
        Task<AccountBalance[]> GetAccountBalances(AccountBalanceRequest accountBalanceRequest);
        Task<decimal?> GetAccountBalanceByValueDate(string accountNumber, DateTime valueDate);
    }
}
