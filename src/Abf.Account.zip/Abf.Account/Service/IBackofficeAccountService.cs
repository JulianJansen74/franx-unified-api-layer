﻿#nullable enable
using Abf.Account.Common;

namespace Abf.Account.Service;

public interface IBackofficeAccountService
{
    Task<BackofficeName> GetBackofficeForAccountWithFallbackAsync(string? accountNumberFromBody,
        CancellationToken cancellationToken);

    BackofficeName GetBackofficeFromHeader();

    Task<Dictionary<string, BackofficeName>> GetBackofficeForAccountsAsync(
        IEnumerable<string>? accountNumbers, CancellationToken cancellationToken);

    Task UpdateAccountStatusToClosedAsync(string accountNumber, CancellationToken cancellationToken);
}
