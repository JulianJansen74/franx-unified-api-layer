﻿using Abf.Account.Models.AccountBalance;

namespace Abf.Account.Service
{
    public class AccountBalanceService : IAccountBalanceService
    {
        public Task<AccountBalance[]> GetAccountBalances(AccountBalanceRequest accountBalanceRequest)
        {
            throw new NotImplementedException();
        }

        public Task<decimal?> GetAccountBalanceByValueDate(string accountNumber, DateTime valueDate)
        {
            throw new NotImplementedException();
        }
    }
}
