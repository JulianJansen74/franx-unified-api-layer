﻿namespace Abf.Account.Service.HttpClients.Cdm.Models
{
    public class CorporateIdentifier
    {
        public int Id { get; set; }
    }
}
