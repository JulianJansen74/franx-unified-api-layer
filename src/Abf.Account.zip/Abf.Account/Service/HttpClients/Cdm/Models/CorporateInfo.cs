﻿namespace Abf.Account.Service.HttpClients.Cdm.Models
{
    public class CorporateInfo
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public CorporateInfoDetails Details { get; set; }

        public CorporateInfoDefinitions Definitions { get; set; }

        public LeiInfo Lei { get; set; }

        public Address[] Addresses { get; set; }

        public PersonIdentifier[] Persons { get; set; }

        public class CorporateInfoDetails
        {
            public string CountryCode { get; set; }
            public string NominatedAccount { get; set; }
            public string Iban { get; set; }
            public string AccountNumber { get; set; }
            public string InitialMarginAccountNumber { get; set; }
            public string VariationMarginAccountNumber { get; set; }
        }

        public class CorporateInfoDefinitions
        {
            public int TierId { get; set; }
            public int? SubTierId { get; set; }
            public decimal? DualSigningThreshold { get; set; }
            public int PortfolioId { get; set; }
            public string PortfolioName { get; set; }
        }

        public class LeiInfo
        {
            public string Code { get; set; }
            public string Status { get; set; }
            public DateTime ExpiryDate { get; set; }
        }

        public class Address
        {
            public string Type { get; set; }
            public string Address1 { get; set; }
            public string Address2 { get; set; }
            public string Address3 { get; set; }
            public string HouseNumber { get; set; }
            public string City { get; set; }
            public string Country { get; set; }
            public string CountryCode { get; set; }
            public string PostalCode { get; set; }
        }

        public class PersonIdentifier
        {
            public Guid Id { get; set; }
            public string Name { get; set; }
        }
    }
}
