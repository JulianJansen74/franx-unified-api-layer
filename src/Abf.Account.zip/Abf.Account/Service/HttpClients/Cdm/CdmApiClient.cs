﻿using Abf.Account.Configuration;
using Abf.Account.Service.HttpClients.Cdm.Models;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Abf.Account.Service.HttpClients.Cdm
{
    public class CdmApiClient : ICdmApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<CdmApiClient> _logger;

        public CdmApiClient(HttpClient httpClient, ILogger<CdmApiClient> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
        }

        public async Task<CorporateInfo> GetCorporateInfo(int corporateId, bool includeAddresses,
            bool includeCountryCode, CancellationToken cancellationToken)
        {
            var requestPath = $"api/v1/corporate-info/{corporateId}";

            var queryParams = new Dictionary<string, string>
            {
                { "includeAddresses", includeAddresses.ToString() },
                { "includeCountryCode", includeCountryCode.ToString() }
            };

            requestPath = QueryHelpers.AddQueryString(requestPath, queryParams);

            _logger.LogInformation("Get corporate info from {requestPath}", requestPath);
            var requestMessage = new HttpRequestMessage(HttpMethod.Get, requestPath);
            var httpResponseMessage = await _httpClient.SendAsync(requestMessage, cancellationToken);

            _logger.LogInformation("Get corporate info response with {statusCode}", httpResponseMessage.StatusCode);

            httpResponseMessage.EnsureSuccessStatusCode();

            var result = await httpResponseMessage.Content.ReadAsStringAsync(cancellationToken);

            return JsonSerializer.Deserialize<CorporateInfo>(result, SerializerOptions.DefaultSettings);
        }

        public async Task<CorporateIdentifier> GetCorporateIdentifierByAccountNumber(string accountNumber,
            CancellationToken cancellationToken)
        {
            var requestPath = "api/v1/corporate-info/corporate-id";
            var queryParams = new Dictionary<string, string> { { "accountNumber", accountNumber } };

            requestPath = QueryHelpers.AddQueryString(requestPath, queryParams);

            _logger.LogInformation("Get corporate identifier by account number from {requestPath}", requestPath);

            var requestMessage = new HttpRequestMessage(HttpMethod.Get, requestPath);
            var httpResponseMessage = await _httpClient.SendAsync(requestMessage, cancellationToken);

            _logger.LogInformation("Get corporate identifier by account number response with {statusCode}",
                httpResponseMessage.StatusCode);

            httpResponseMessage.EnsureSuccessStatusCode();

            var result = await httpResponseMessage.Content.ReadAsStringAsync(cancellationToken);

            return JsonSerializer.Deserialize<CorporateIdentifier>(result, SerializerOptions.DefaultSettings);
        }
    }
}
