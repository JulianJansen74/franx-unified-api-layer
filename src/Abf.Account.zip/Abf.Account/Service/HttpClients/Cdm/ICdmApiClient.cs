﻿using Abf.Account.Service.HttpClients.Cdm.Models;

namespace Abf.Account.Service.HttpClients.Cdm
{
    public interface ICdmApiClient
    {
        Task<CorporateInfo> GetCorporateInfo(int corporateId, bool includeAddresses,
            bool includeCountryCode, CancellationToken cancellationToken);

        Task<CorporateIdentifier> GetCorporateIdentifierByAccountNumber(string accountNumber,
            CancellationToken cancellationToken);
    }
}
