using System;
using System.ComponentModel.DataAnnotations;

namespace Abf.Account.Validation;

/// <summary>
/// Validates a <see cref="decimal"/> amount without formatting via <see cref="System.Globalization.CultureInfo.CurrentCulture"/>,
/// so rules stay consistent for JSON payloads regardless of server or thread locale (see CurrencyAmount XML docs).
/// </summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, AllowMultiple = false)]
public sealed class Iso4217DecimalAmountAttribute : ValidationAttribute
{
    public const int MaxIntegerDigits = 18;
    public const int MaxFractionalDigits = 5;

    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        if (value == null)
        {
            return ValidationResult.Success;
        }

        if (value is not decimal amount)
        {
            return MemberResult("Amount must be a decimal.", validationContext);
        }

        var bits = decimal.GetBits(amount);
        var scale = (bits[3] >> 16) & 0xFF;
        if (scale > MaxFractionalDigits)
        {
            return MemberResult(ErrorMessage ?? BuildConstraintsMessage(validationContext), validationContext);
        }

        var integerPart = decimal.Truncate(decimal.Abs(amount));
        if (integerPart == 0)
        {
            return ValidationResult.Success;
        }

        var digitCount = 0;
        var remaining = integerPart;
        while (remaining >= 1)
        {
            digitCount++;
            if (digitCount > MaxIntegerDigits)
            {
                return MemberResult(ErrorMessage ?? BuildConstraintsMessage(validationContext), validationContext);
            }

            remaining = decimal.Truncate(remaining / 10);
        }

        return ValidationResult.Success;
    }

    private static string BuildConstraintsMessage(ValidationContext validationContext)
    {
        var displayName = validationContext?.DisplayName ?? "Amount";
        return $"{displayName} must comply with ISO 4217 constraints (max {MaxIntegerDigits} integer digits, max {MaxFractionalDigits} fractional digits).";
    }

    private static ValidationResult MemberResult(string message, ValidationContext validationContext)
    {
        return validationContext?.MemberName is { Length: > 0 } name
            ? new ValidationResult(message, [name])
            : new ValidationResult(message);
    }
}
