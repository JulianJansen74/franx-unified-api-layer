﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace Abf.Account.Configuration
{
    public static class SerializerOptions
    {
        public static readonly JsonSerializerOptions DefaultSettings = new()
        {
            PropertyNameCaseInsensitive = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            Converters = { new JsonStringEnumConverter() }
        };
    }
}
