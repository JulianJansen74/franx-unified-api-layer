﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Abf.Account.Tests")]
