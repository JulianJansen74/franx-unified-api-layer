﻿using System.Text.Json.Serialization;

namespace Abf.Account.Converters
{
    public class JsonConverterWithArgsAttribute : JsonConverterAttribute
    {
        public JsonConverterWithArgsAttribute(Type converterType, params object[] converterArguments)
        {
            ConverterType = converterType;
            ConverterArguments = converterArguments;
        }

        public new Type ConverterType { get; }
        public object[] ConverterArguments { get; }

        public override JsonConverter CreateConverter(Type typeToConvert)
        {
            return (JsonConverter)Activator.CreateInstance(ConverterType, ConverterArguments)!;
        }
    }
}
