﻿namespace Abf.Account
{
    public static class Constants
    {
        public const string IdempotencyKeyHeaderName = "IdempotencyKey";
        public const string BackofficeIdHeaderName = "X-Backoffice-Id";
        public const string SqlDistributedCacheTable = "DistributedCache";
    }
}
