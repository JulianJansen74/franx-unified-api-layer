﻿namespace Abf.Account.Models
{
    public class ErrorDetails
    {
        public int StatusCode { get; set; }

        public string Message { get; set; }

        public string Details { get; set; }

        public string StackTrace { get; set; }
    }
}
