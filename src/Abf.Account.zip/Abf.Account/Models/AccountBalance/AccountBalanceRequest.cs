﻿namespace Abf.Account.Models.AccountBalance
{
    public class AccountBalanceRequest
    {
        public string BbanAccountNumber { get; set; }
        public DateTime BalanceDate { get; set; }
        public string[] Currencies { get; set; }
    }
}
