﻿namespace Abf.Account.Models.AccountBalance
{
    public class AccountBalance
    {
        public string Currency { get; set; }
        public decimal Balance { get; set; }
    }
}
