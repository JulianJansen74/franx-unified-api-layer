﻿using FluentValidation;

namespace Abf.Account.Models.AccountBalance
{
    public class AccountBalanceRequestValidator : AbstractValidator<AccountBalanceRequest>
    {
        private const int MinAccountNumberLength = 8;
        private const int MaxAccountNumberLength = 50;
        private const string BasicLettersAndDigitsAndDelimiters = @"^[a-zA-Z0-9\s.-]+$";

        public AccountBalanceRequestValidator()
        {
            PropertyValidation();
        }

        private void PropertyValidation()
        {
            RuleFor(x => x.BbanAccountNumber)
                .NotEmpty()
                .MinimumLength(MinAccountNumberLength)
                .MaximumLength(MaxAccountNumberLength)
                .Matches(BasicLettersAndDigitsAndDelimiters);

            RuleFor(x => x.BalanceDate).NotEmpty();

            RuleFor(x => x.Currencies)
                .ForEach(c => c
                    .Matches("^[A-Z]{3}$")
                    .WithMessage("'Currencies' can only be 3 upper case characters.")
                ).When(x => x.Currencies != null);
        }
    }
}
