# CDM API

# DB Migrations

## Add migrations

Navigate to the root of the repository

```
dotnet ef migrations add initial-migration -p src/Franx.Core.CDM/Franx.Core.CDM.csproj -s src/Franx.Core.CDM.Api/Franx.Core.CDM.Api.csproj -o DataStore/Migrations
```

## Run migrations
Navigate to the root of the repository

```
dotnet ef database update -p src/Franx.Core.CDM/Franx.Core.CDM.csproj -s src/Franx.Core.CDM.Api/Franx.Core.CDM.Api.csproj
```