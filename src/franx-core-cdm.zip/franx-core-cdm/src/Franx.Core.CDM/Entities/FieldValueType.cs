﻿namespace Franx.Core.CDM.Entities;

public enum FieldValueType
{
    Text, Integer
}
