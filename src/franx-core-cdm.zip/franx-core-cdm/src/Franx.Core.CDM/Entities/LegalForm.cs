﻿namespace Franx.Core.CDM.Entities;

public class LegalForm
{
    public int Id { get; set; }
    public string Code { get; set; }
    public string ShortCode { get; set; }
    public string CountryCode { get; set; }
    public string Name { get; set; }
}
