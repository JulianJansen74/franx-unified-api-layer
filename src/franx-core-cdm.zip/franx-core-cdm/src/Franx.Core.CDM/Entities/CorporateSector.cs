﻿namespace Franx.Core.CDM.Entities;

public class CorporateSector
{
    public int Id { get; set; }
    public string ExternalBusinessKey { get; set; }
    public string Description { get; set; }
}
