﻿using System.Collections.Generic;

namespace Franx.Core.CDM.Entities;

public class LegalActivity
{
    public int Id { get; set; }
    public string SbiCode { get; set; }
    public string Description { get; set; }
    public List<Corporate> Corporates { get; set; }
}
