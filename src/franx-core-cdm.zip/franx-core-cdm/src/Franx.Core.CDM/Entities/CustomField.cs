﻿namespace Franx.Core.CDM.Entities;

public class CustomField
{
    public int Id { get; set; }
    public string Code { get; set; }
    public string Name { get; set; }
    public FieldValueType ValueType { get; set; }
    public bool Required { get; set; }
}
