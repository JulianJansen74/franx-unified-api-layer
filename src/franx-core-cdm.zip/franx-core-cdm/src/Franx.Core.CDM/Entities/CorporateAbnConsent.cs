using System;

namespace Franx.Core.CDM.Entities;

public class CorporateAbnConsent
{
    public int Id { get; set; }
    public int CorporateId { get; set; }
    public string ClientId { get; set; } = null!;
    public string ApiKey { get; set; } = null!;
    public AbnConsentStatus Status { get; set; }
    public DateTime Created { get; set; }
    public string CreatedBy { get; set; } = null!;
    public DateTime? Modified { get; set; }
    public string? ModifiedBy { get; set; } 
}
