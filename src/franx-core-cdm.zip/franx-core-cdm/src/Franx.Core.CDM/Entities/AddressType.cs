﻿namespace Franx.Core.CDM.Entities;

public enum AddressType
{
    Registered,
    Correspondence
}
