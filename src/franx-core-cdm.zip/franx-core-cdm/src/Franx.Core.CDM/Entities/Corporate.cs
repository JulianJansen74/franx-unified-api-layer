﻿using System;
using System.Collections.Generic;

namespace Franx.Core.CDM.Entities;

public class Corporate
{
    public int Id { get; set; }
    public IList<LegalActivity> LegalActivities { get; set; } = new List<LegalActivity>();
    public int? CorporateSectorId { get; set; }
    public CorporateSector? CorporateSector { get; set; }
    public int? SegmentId { get; set; }
    public Segment Segment { get; set; }
    public PlattformSettings PlattformSettings { get; set; } = new PlattformSettings();
    public string ClientFileId { get; set; }
    public string Name { get; set; }
    public string CountryOfIncorporation { get; set; }
    public string RegistrationNumber { get; set; }
    public string? LeiCode { get; set; }
    public LeiStatus? LeiStatus { get; set; }
    public DateTime? LeiExpiryDate { get; set; }
    public string? PhoneNumber { get; set; }
    public string? Email { get; set; }
    public IList<Address> Addresses { get; set; } = new List<Address>();
    public List<CustomFieldValue> CustomFieldValues { get; set; }
    public int? LegalFormId { get; set; }
    public LegalForm? LegalForm { get; set; }
    public CorporateStatus Status { get; set; }
    public string BlancoPartyId { get; set; }
    public DateTime Created { get; set; }
    public string CreatedBy { get; set; }
    public DateTime Modified { get; set; }
    public string ModifiedBy { get; set; }
    public DateTime? IncorporationDate { get; set; }
    public RiskClass? RiskClassification { get; set; }
    public DateTime? RiskClassifiedOn { get; set; }
    public long? BCNumber { get; set; }
    public bool? MifidTestCompleted { get; set; }
    public string Version { get; set; }
    public List<CorporateTaxCountry> TaxCountries { get; set; }
    public bool? AccountFee { get; set; } = true;
    public decimal? AccountFeeAmount { get; set; }
}
