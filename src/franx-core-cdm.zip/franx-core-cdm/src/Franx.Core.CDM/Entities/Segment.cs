﻿namespace Franx.Core.CDM.Entities;

public class Segment
{
    public int Id { get; set; }
    public string Code { get; set; }
    public string Description { get; set; }
}
