namespace Franx.Core.CDM.Entities;

public enum AbnConsentStatus
{
    Valid,
    Invalid,
    Revoked,
    Expired
}
