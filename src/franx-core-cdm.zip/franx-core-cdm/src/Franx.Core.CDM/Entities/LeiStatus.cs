﻿namespace Franx.Core.CDM.Entities;

public enum LeiStatus
{
    Annulled, Duplicate, Issued, Lapsed, Merged, Retired
}
