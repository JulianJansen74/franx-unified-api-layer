﻿namespace Franx.Core.CDM.Entities;

public enum RiskClass
{
    Unknown, Low, Medium, High, Unacceptable
}
