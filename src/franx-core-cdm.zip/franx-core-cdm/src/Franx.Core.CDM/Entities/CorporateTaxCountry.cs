﻿namespace Franx.Core.CDM.Entities;

public class CorporateTaxCountry
{
    public int Id { get; set; }
    public int CorporateId { get; set; }
    public string CountryCode { get; set; }
    public string TaxNumber { get; set; }
}
