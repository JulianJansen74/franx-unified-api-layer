﻿using System;
using System.Collections.Generic;
using Franx.Core.CDM.Models;

namespace Franx.Core.CDM.Entities;

public class Portfolio
{
    public int Id { get; set; }
    public int CorporateId { get; set; }
    public string Name { get; set; }
    public PortfolioType Type { get; set; }
    public PortfolioStatus Status { get; set; }
    public string NominatedAccount { get; set; }
    public virtual Corporate Corporate { get; set; }
    public DateTime Created { get; set; }
    public string CreatedBy { get; set; }
    public DateTime Modified { get; set; }
    public string ModifiedBy { get; set; }
    public string Version { get; set; }
    public Backoffice BackofficeId { get; set; }
    
    // Navigation properties
    public ICollection<Account> Accounts { get; set; } = new List<Account>();
}

public enum PortfolioType
{
    Corporate = 1,
    Internal
}

public enum PortfolioStatus
{
    Open = 1,
    Closed = 2,
    PendingOpening = 3,
    Blocked = 4
}
