﻿using System;

namespace Franx.Core.CDM.Entities;

public class PlattformSettings
{
    public int Id { get; set; }
    public int TierId { get; set; }
    public int SubTierId { get; set; }
    public bool DualSigningEnabled { get; set; }
    public decimal? DualSigningThreshold { get; set; }
    public string PreferredLanguage { get; set; }
    public bool FxDerivativeEnabled { get; set; }
    public decimal ExpectedYarlyVolumeTrade { get; set; }
    public bool HardBalanceCheckIM { get; set; } = false;
    public DateTime Created { get; set; }
    public string CreatedBy { get; set; }
    public DateTime Modified { get; set; }
    public string ModifiedBy { get; set; }
    public bool IncludeImInVmExposure { get; set; }
}
