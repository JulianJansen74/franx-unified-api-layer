﻿using System;

namespace Franx.Core.CDM.Entities;

public class CustomFieldValue
{
    public int Id { get; set; }
    public int CorporateId { get; set; }
    public int CustomFieldId { get; set; }
    public CustomField CustomField { get; set; }
    public string Value { get; set; }
    public DateTime Created { get; set; }
    public string CreatedBy { get; set; }
    public DateTime Modified { get; set; }
    public string ModifiedBy { get; set; }
}
