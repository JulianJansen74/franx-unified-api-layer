﻿using System;
using Franx.Core.CDM.Models;

namespace Franx.Core.CDM.Entities;

public class Account
{
    public int Id { get; set; }
    public int PortfolioId { get; set; }
    public string Number { get; set; }
    public AccountType Type { get; set; }
    public AccountStatus Status { get; set; }
    public virtual Portfolio Portfolio { get; set; }
    public DateTime Created { get; set; }
    public string CreatedBy { get; set; }
    public DateTime Modified { get; set; }
    public string ModifiedBy { get; set; }
}
