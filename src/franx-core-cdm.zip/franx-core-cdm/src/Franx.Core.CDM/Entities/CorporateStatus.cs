﻿namespace Franx.Core.CDM.Entities;

public enum CorporateStatus
{
    Onboarding, 
    Active, 
    Inactive, 
    Offboarding,
    Closed
}
