﻿namespace Franx.Core.CDM.Models
{
    public class CorporateInfoRequest
    {
        public int CorporateId { get; set; }
        public bool IncludeAddresses { get; set; }
        public bool IncludeCountryCode { get; set; }
    }
}
