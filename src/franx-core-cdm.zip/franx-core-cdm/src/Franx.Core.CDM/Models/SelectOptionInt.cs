﻿namespace Franx.Core.CDM.Models
{
    public class SelectOptionInt : SelectOption<int>
    {
        public SelectOptionInt() { }
        public SelectOptionInt(int value)
        {
            Value = value;
        }
        public SelectOptionInt(int value, string label)
        {
            Value = value;
            Label = label;
        }
    }
}
