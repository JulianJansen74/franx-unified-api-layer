﻿namespace Franx.Core.CDM.Models
{
    public class PersonIdentifier
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
