﻿namespace Franx.Core.CDM.Models
{
    public class AddressInfo
    {
        public string Type { get; set; }
        public string Address1 { get; set; }
        public string? Address2 { get; set; }
        public string Address3 { get; set; }
        public string? HouseNumber { get; set; }
        public string? City { get; set; }
        public string? Country { get; set; }
        public string? CountryCode { get; set; }
        public string? PostalCode { get; set; }
    }
}
