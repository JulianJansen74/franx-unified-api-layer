﻿namespace Franx.Core.CDM.Models;

public enum AccountStatus
{
    Open = 1,
    Closed,
    Dormant,
    Frozen,
    AwaitingTransaction,
    Recycled,
    Retired,
    BlockWithdrawals,
    FirstPayment,
    BlockDeposits
}
