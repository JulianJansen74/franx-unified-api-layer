﻿namespace Franx.Core.CDM.Models;

public enum Backoffice : byte
{
    Matrix = 1,
    Nolan = 2
}
