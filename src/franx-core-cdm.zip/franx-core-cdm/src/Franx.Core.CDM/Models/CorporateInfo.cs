﻿namespace Franx.Core.CDM.Models
{
    public class CorporateInfo
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public CorporateInfoDetails Details { get; set; }

        public CorporateInfoDefinitions Definitions { get; set; }

        public LeiInfo? Lei { get; set; }

        public AddressInfo[]? Addresses { get; set; }

        public PersonIdentifier[]? Persons { get; set; }
        public string Status { get; set; }
        public string? Email { get; set; }
        public string PreferredLanguage { get; set; }
        public bool FxDerivativeEnabled { get; set; }
        public bool? AccountFee { get; set; } = true;
        public decimal? AccountFeeAmount { get; set; }
    }
}
