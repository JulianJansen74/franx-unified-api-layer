﻿namespace Franx.Core.CDM.Models
{
    public class SelectOption<T>
    {
        public T Value { get; set; }
        public string Label { get; set; }
    }
}
