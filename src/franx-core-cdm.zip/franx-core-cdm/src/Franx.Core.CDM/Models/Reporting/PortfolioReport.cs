﻿using Franx.Core.CDM.Entities;

namespace Franx.Core.CDM.Models.Reporting
{
    public class PortfolioReport
    {
        public int PortfolioId { get; set; }
        public string PortfolioName { get; set; }
        public PortfolioType PortfolioType { get; set; }
        public PortfolioStatus Status { get; set; }
        public string NominatedAccount { get; set; }
        public int CorporateId { get; set; }
        public Backoffice Backoffice { get; set; }
    }
}
