﻿using System;

namespace Franx.Core.CDM.Models.Reporting
{
    public class AccountReport
    {
        public int AccountId { get; set; }
        public string? PortfolioName { get; set; }
        public string Number { get; set; }
        public AccountType Type { get; set; }
        public AccountStatus Status { get; set; }
        public int PortfolioId { get; set; }
        public int CorporateId { get; set; }
        public string CorporateName { get; set; }
        public DateTime Created { get; set; }
        public string RegistrationNumber { get; set; }
        public string? ZipCode { get; set; }
        public string? Country { get; set; }
        public int? LegalFormId { get; set; }
        public string? LegalFormShortCode { get; set; }
    }
}
