﻿using System;

namespace Franx.Core.CDM.Models
{
    public class LeiInfo
    {
        public string? Code { get; set; }
        public string Status { get; set; }
        public DateTime? ExpiryDate { get; set; }
    }
}
