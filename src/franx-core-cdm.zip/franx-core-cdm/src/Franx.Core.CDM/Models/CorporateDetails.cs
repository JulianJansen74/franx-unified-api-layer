﻿using System;
using Franx.Core.CDM.Entities;

namespace Franx.Core.CDM.Models
{
    public class CorporateDetails
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Email { get; set; }
        public CorporateStatus Status { get; set; }
        public SelectOptionInt? LegalForm { get; set; }
        public string RegistrationNumber { get; set; }
        public string CountryOfIncorporation { get; set; }
        public string? LeiNumber { get; set; }
        public DateTime? LeiExpiryDate { get; set; }
        public LeiStatus? LeiStatus { get; set; }
        public string PreferredLanguage { get; set; }
        public string BlancoPartyId { get; set; }
        public AddressDto? Address { get; set; }
        public AddressDto? CorrespondenceAddress { get; set; }
        public LegalActivity[] LegalActivities { get; set; }
        public DateTime? IncorporationDate { get; set; }
        public RiskClass? RiskClassification { get; set; }
        public DateTime? RiskClassifiedOn { get; set; }
        public long? BCNumber { get; set; }
        public TaxCountryDetails[] TaxCountries { get; set; }
        public DateTime OnboardedOn { get; set; }
        public DateTime? OffboardedOn { get; set; }
        public bool? MifidTestCompleted { get; set; }
        public bool IncludeImInVmExposure { get; set; }
        public bool FxDerivativeEnabled { get; set; }
        public bool? AccountFee { get; set; } = true;
        public decimal? AccountFeeAmount { get; set; }
        public string Version { get; set; }
        public CorporateOverviewConfiguration? CorporateConfiguration { get; set; }

        public class LegalActivity
        {
            public int Id { get; set; }
            public string Code { get; set; }
            public string Description { get; set; }
        }
        public class TaxCountryDetails
        {
            public int Id { get; set; }
            public string CountryCode { get; set; }
            public string TaxNumber { get; set; }
        }
        public class AddressDto
        {
            public int Id { get; set; }
            public string AddressLine1 { get; set; }
            public string? AddressLine2 { get; set; }
            public string? HouseNumber { get; set; }
            public string? ZipCode { get; set; }
            public string? City { get; set; }
            public string? Country { get; set; }
            public AddressType Type { get; set; }
        }
    }
}
