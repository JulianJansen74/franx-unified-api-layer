﻿namespace Franx.Core.CDM.Models
{
    public class CorporateInfoDetails
    {
        public string? CountryCode { get; set; }
        public string NominatedAccount { get; set; }
        public string? Iban { get; set; }
        public string? AccountNumber { get; set; }
        public string? InitialMarginAccountNumber { get; set; }
        public string? VariationMarginAccountNumber { get; set; }
    }
}
