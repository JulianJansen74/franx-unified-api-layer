﻿namespace Franx.Core.CDM.Models
{
    public class CorporateOverviewConfiguration
    {
        public string? RelationshipManager { get; set; }
        public SelectOptionInt? Segment { get; set; }
        public SelectOptionInt? CorporateSector { get; set; }
        public int? CustomerTier { get; set; }
        public int? CustomerSubTier { get; set; }
        public string FccmTier { get; set; }
        public bool DualSigning { get; set; }
        public decimal? DualSigningThreshold { get; set; }
        public decimal ExpectedYearlyTradeVolume { get; set; }
        public bool HardBalanceCheckIM { get; set; } = false;
    }
}
