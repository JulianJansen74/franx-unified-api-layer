﻿namespace Franx.Core.CDM.Models
{
    public class CorporateIdentifier
    {
        public int Id { get; set; }
    }
}
