namespace Franx.Core.CDM.Models;

public class CorporateAbnConsentDto
{
    public string ClientId { get; set; } = null!;
    public string ApiKey { get; set; } = null!;
}
