﻿namespace Franx.Core.CDM.Models
{
    public class CorporateInfoDefinitions
    {
        public int TierId { get; set; }
        public int? SubTierId { get; set; }
        public decimal? DualSigningThreshold { get; set; }
        public bool HardBalanceCheckIM { get; set; }
        public int PortfolioId { get; set; }
        public string PortfolioName { get; set; }
        public Backoffice Backoffice { get; set; }
        public bool DualSigningEnabled { get; set; }
    }
}
