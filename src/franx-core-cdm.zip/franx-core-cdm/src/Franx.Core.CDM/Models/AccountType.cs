﻿namespace Franx.Core.CDM.Models;

public enum AccountType
{
    Iban = 0,
    Bban,
    InitialMargin,
    VariationMargin,
    Internal
}
