using System.Collections.Generic;

namespace Franx.Core.CDM;

public class Constants
{
    public class MaxLength
    {
        public const int DefaultDescriptionField = 400;
        public const int CreatedBy = 50;
        public const int ModifiedBy = 50;
        public const int BlancoPartyId = 50;

        public class LegalActivity
        {
            public const int SbiCode = 100;
        }

        public class CorporateSector
        {
            public const int ExternalBusinessKey = 50;
        }

        public class Segment
        {
            public const int Code = 50;
        }

        public class CustomField
        {
            public const int Code = 100;
            public const int Name = 20;
        }

        public class Address
        {
            public const int AddressLine1 = 200;
            public const int AddressLine2 = 200;
            public const int HouseNumber = 200;
            public const int ZipCode = 100;
            public const int City = 100;
            public const int Country = 100;
        }

        public class Account
        {
            public const int Number = 100;
        }

        public class Corporate
        {
            public const int ClientFileId = 100;
            public const int Name = 200;
            public const int CountryOfIncorporation = 100;
            public const int RegistrationNumber = 100;
            public const int RelationshipManager = 200;
            public const int BCNumber = 200;
            public const int LeiCode = 50;
            public const int PhoneNumber = 100;
            public const int Email = 200;
            public const int PreferredLanguage = 100;
            public const int TaxNumber = 100;
        }

        public class Portfolio
        {
            public const int Name = 200;
            public const int NominatedAccount = 100;
        }

        public class CorporateTaxCountry
        {
            public const int TaxNumber = 100;
            public const int CountryCode = 2;
        }

        public class CorporateAbnConsent
        {
            public const int ClientId = 200;
            public const int ApiKey = 200;
            public const int Status = 200;
        }
    }

    public static readonly Dictionary<string, string> Languages = new()
    {
        { "EN", "English" },
        { "NL", "Dutch" }
    };

    // The numbers below this are reserved for data migration from MOL
    public const int IdentitySeed = 500_000;

    public const int DefaultSubTier = 5;

    public const int DefaultCustomerTier = 6;

    public static class CorporateCustomFields
    {
        public const string RelationshipManager = "RelationshipManager";
        public const string FCCMTiering = "FCCMTiering";
    }

    public static class CacheKey
    {
        public const string StaticDataCountries = "StaticDataCountriesList";
    }

    public static class AzureAd
    {
        public const string Audience = "AzureAd:Audience";
        public const string Authority = "AzureAd:Authority";
        public const string ClientId = "AzureAd:ClientId";
    }
}
