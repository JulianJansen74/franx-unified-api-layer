using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.DataStore.Configurations;
using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;

namespace Franx.Core.CDM.DataStore;

public class CDMDBContext : DbContext
{
    public CDMDBContext(DbContextOptions options) : base(options) { }

    public override int SaveChanges()
    {
        var res = base.SaveChanges();
        return res;
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken())
    {
        var res = await base.SaveChangesAsync(cancellationToken);
        return res;
    }

    public virtual DbSet<Corporate> Corporates { get; set; }
    public virtual DbSet<Segment> Segments { get; set; }
    public virtual DbSet<CorporateSector> CorporateSectors { get; set; }
    public virtual DbSet<LegalActivity> LegalActivities { get; set; }
    public virtual DbSet<LegalForm> LegalForms { get; set; }
    public virtual DbSet<Portfolio> Portfolios { get; set; }
    public virtual DbSet<Account> Accounts { get; set; }
    public virtual DbSet<CustomField> CustomFields { get; set; }
    public virtual DbSet<CorporateTaxCountry> CorporateTaxCountries { get; set; }
    public virtual DbSet<Address> Addresses { get; set; }
    public virtual DbSet<CorporateAbnConsent> CorporateAbnConsents { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new AddressConfiguration());
        modelBuilder.ApplyConfiguration(new CorporateConfiguration());
        modelBuilder.ApplyConfiguration(new CorporateSectorConfiguration());
        modelBuilder.ApplyConfiguration(new LegalActivityConfiguration());
        modelBuilder.ApplyConfiguration(new SegmentConfiguration());
        modelBuilder.ApplyConfiguration(new PlattformSettingsConfiguration());
        modelBuilder.ApplyConfiguration(new CustomFieldConfiguration());
        modelBuilder.ApplyConfiguration(new CustomFieldValueConfiguration());
        modelBuilder.ApplyConfiguration(new PortfolioConfiguration());
        modelBuilder.ApplyConfiguration(new AccountConfiguration());
        modelBuilder.ApplyConfiguration(new CorporateTaxCountryConfiguration());
        modelBuilder.ApplyConfiguration(new LegalFormConfiguration());
        modelBuilder.ApplyConfiguration(new CorporateAbnConsentConfiguration());
    }
}
