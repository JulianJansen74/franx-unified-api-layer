﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;

namespace Franx.Core.CDM.DataStore.Repositories;

public class CustomFieldsRepository : ICustomFieldsRepository
{
    private readonly CDMDBContext _context;

    public CustomFieldsRepository(CDMDBContext context)
    {
        _context = context;
    }

    public async Task<string?> Get(Corporate corporate, string code, CancellationToken cancellationToken)
    {
        var customFieldId = (await _context.CustomFields.FirstOrDefaultAsync(x => x.Code == code, cancellationToken))?.Id;
        if (customFieldId == null)
        {
            throw new ArgumentException($"{code} is not valid custom field code", nameof(code));
        }
        var existingFieldValue = corporate.CustomFieldValues.Find(x => x.CustomFieldId == customFieldId.Value);
        return existingFieldValue?.Value;
    }

    public async Task Upsert(List<CustomFieldValue>? corporatesFieldValues, string code, string? value, string user)
    {
        if (string.IsNullOrEmpty(value) && corporatesFieldValues is null) return;

        var customFieldId = (await _context.CustomFields.FirstOrDefaultAsync(x => x.Code == code))?.Id;
        if (customFieldId == null)
            throw new ArgumentException($"{code} is not valid custom field code");

        if (corporatesFieldValues != null)
        {
            var existingFieldValue = corporatesFieldValues.FirstOrDefault(x => x.CustomFieldId == customFieldId.Value);
            if (string.IsNullOrEmpty(value))
            {
                if (existingFieldValue != null) corporatesFieldValues.Remove(existingFieldValue);
                return;
            }

            if (existingFieldValue != null)
            {
                if (string.Equals(existingFieldValue.Value, value))
                {
                    return;
                }

                existingFieldValue.Value = value;
                existingFieldValue.ModifiedBy = user;
                existingFieldValue.Modified = DateTime.UtcNow;
            }
            else
            {
                corporatesFieldValues.Add(new CustomFieldValue
                {
                    ModifiedBy = user,
                    CustomFieldId = customFieldId.Value,
                    Value = value,
                    CreatedBy = user
                });
            }
        }
    }
}
