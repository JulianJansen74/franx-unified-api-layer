﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;

namespace Franx.Core.CDM.DataStore.Repositories
{
    public interface ICorporateSectorRepository
    {
        Task<IList<CorporateSector>> GetAll();
        Task<CorporateSector> GetById(int corporateSectorId);
        Task<CorporateSector> FindByDescription(string corporateSector);
    }
}
