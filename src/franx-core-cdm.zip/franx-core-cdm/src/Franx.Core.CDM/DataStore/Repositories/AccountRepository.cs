﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Franx.Core.CDM.Models.Reporting;
using Franx.Core.CDM.Models;

namespace Franx.Core.CDM.DataStore.Repositories;

public class AccountRepository : IAccountRepository
{
    private readonly CDMDBContext _context;

    public AccountRepository(CDMDBContext context)
    {
        _context = context;
    }

    public async Task Add(Account account)
    {
        await _context.Accounts.AddAsync(account);
    }

    public async Task<IReadOnlyCollection<Account>> GetByPortfolioId(int portfolioId)
    {
        return await _context.Accounts.Include(x => x.Portfolio).AsNoTracking()
            .Where(c => c.PortfolioId == portfolioId).ToListAsync();
    }

    public Task<Account?> GetByNumber(string number)
        => _context.Accounts.FirstOrDefaultAsync(x => x.Number == number);


    public async Task<Account?> GetByAccountNumber(string accountNumber)
    {
        return await _context.Accounts
            .Include(x => x.Portfolio)
            .ThenInclude(x => x.Corporate)
            .AsNoTracking()
            .Where(c => c.Number == accountNumber)
            .FirstOrDefaultAsync();
    }
}
