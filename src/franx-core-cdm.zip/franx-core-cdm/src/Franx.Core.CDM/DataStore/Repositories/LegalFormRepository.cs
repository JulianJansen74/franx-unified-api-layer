﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;

namespace Franx.Core.CDM.DataStore.Repositories;

public class LegalFormRepository : ILegalFormRepository
{
    private readonly CDMDBContext _context;

    public LegalFormRepository(CDMDBContext context)
    {
        _context = context;
    }

    public async Task<LegalForm?> GetById(int id, CancellationToken cancellationToken = default)
    {
        return await _context.LegalForms.FirstOrDefaultAsync(s => s.Id == id, cancellationToken);
    }

    public async Task<LegalForm?> GetByName(string name, CancellationToken cancellationToken = default)
    {
        return await _context.LegalForms.FirstOrDefaultAsync(s => s.Name == name, cancellationToken);
    }

    public async Task<IList<LegalForm>> GetAll(CancellationToken cancellationToken = default)
    {
        return await _context.LegalForms.AsNoTracking().ToListAsync(cancellationToken);
    }

    public async Task Add(LegalForm legalForm, CancellationToken cancellationToken = default)
    {
        await _context.LegalForms.AddAsync(legalForm, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task Update(LegalForm legalForm, CancellationToken cancellationToken = default)
    {
        _context.LegalForms.Update(legalForm);
        await _context.SaveChangesAsync(cancellationToken);
    }
}
