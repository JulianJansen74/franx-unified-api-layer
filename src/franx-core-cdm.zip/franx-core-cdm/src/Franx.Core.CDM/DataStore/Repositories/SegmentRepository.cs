﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;

namespace Franx.Core.CDM.DataStore.Repositories
{
    public class SegmentRepository : ISegmentRepository
    {
        private readonly CDMDBContext _context;

        public SegmentRepository(CDMDBContext context)
        {
            _context = context;
        }

        public async Task<Segment> FindByDescription(string segment)
        {
            return await _context.Segments.FirstAsync(s => s.Description == segment);
        }

        public async Task<IList<Segment>> GetAll()
        {
            return await _context.Segments.AsNoTracking().ToListAsync();
        }
    }
}
