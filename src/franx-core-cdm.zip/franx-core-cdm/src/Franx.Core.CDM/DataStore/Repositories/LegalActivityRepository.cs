﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;

namespace Franx.Core.CDM.DataStore.Repositories;

public class LegalActivityRepository : ILegalActivityRepository
{
    private readonly CDMDBContext _context;

    public LegalActivityRepository(CDMDBContext context)
    {
        _context = context;
    }

    public Task<LegalActivity?> GetBySbiCode(string sbiCode)
    {
        return _context.LegalActivities.FirstOrDefaultAsync(s => s.SbiCode == sbiCode);
    }
    public async Task<LegalActivity?> GetById(int id, CancellationToken cancellationToken = default)
    {
        return await _context.LegalActivities.FirstOrDefaultAsync(s => s.Id == id, cancellationToken);
    }

    public async Task<IList<LegalActivity>> GetAll(CancellationToken cancellationToken = default)
    {
        return await _context.LegalActivities.ToListAsync(cancellationToken);
    }

    public async Task Add(LegalActivity legalActivity, CancellationToken cancellationToken = default)
    {
        await _context.LegalActivities.AddAsync(legalActivity, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task Update(LegalActivity legalActivity, CancellationToken cancellationToken = default)
    {
        _context.LegalActivities.Update(legalActivity);
        await _context.SaveChangesAsync(cancellationToken);
    }
}
