﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.DataStore.Extensions;
using Franx.Core.CDM.Entities;
using Franx.Core.CDM.Models;
using MassTransit.Initializers;
using Microsoft.EntityFrameworkCore;

namespace Franx.Core.CDM.DataStore.Repositories;

public class CorporateRepository : ICorporateRepository
{
    private readonly CDMDBContext _context;

    public CorporateRepository(CDMDBContext context)
    {
        _context = context;
    }

    public void Add(Corporate corporate)
    {
        _context.Corporates.Add(corporate);
    }

    public void Update(Corporate corporate)
    {
        _context.Corporates.Update(corporate);
    }

    public async Task<Corporate?> GetByBCNumber(long? bcNumber)
    {
        if (bcNumber == null)
            return null;

        return await _context.Corporates
            .IncludeAll()
            .FirstOrDefaultAsync(c => c.BCNumber == bcNumber);
    }

    public Task<Corporate?> GetById(int corporateId, CancellationToken cancellationToken)
    {
        return _context.Corporates
            .IncludeAll()
            .Include(c => c.CorporateSector)
            .Include(c => c.Segment)
            .FirstOrDefaultAsync(c => c.Id == corporateId, cancellationToken);
    }
    
    public async Task<int?> GetCorporateIdByPortfolioId(int portfolioId, CancellationToken cancellationToken)
    {
        var portfolio = await _context.Portfolios.FirstOrDefaultAsync(p => p.Id == portfolioId, cancellationToken);
        return portfolio?.CorporateId;
    }

    public async Task<IEnumerable<Corporate>> GetChunk(int skip, int take)
    {
        return await _context.Corporates.AsNoTracking()
            .OrderBy(p => p.Id)
            .Skip(skip)
            .Take(take)
            .ToArrayAsync();
    }
}
