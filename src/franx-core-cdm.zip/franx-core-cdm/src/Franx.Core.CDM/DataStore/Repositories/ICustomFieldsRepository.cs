﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;

namespace Franx.Core.CDM.DataStore.Repositories;

public interface ICustomFieldsRepository
{
    Task Upsert(List<CustomFieldValue> corporatesFieldValues, string code, string? value, string user);
    Task<string?> Get(Corporate corporate, string code, CancellationToken cancellationToken);
}
