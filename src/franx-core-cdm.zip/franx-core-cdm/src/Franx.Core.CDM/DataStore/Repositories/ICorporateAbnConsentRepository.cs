using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;

namespace Franx.Core.CDM.DataStore.Repositories;

public interface ICorporateAbnConsentRepository
{
    Task<CorporateAbnConsent?> GetLatestByCorporateIdAsync(int corporateId, CancellationToken cancellationToken);
}
