﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;

namespace Franx.Core.CDM.DataStore.Repositories
{
    public class CorporateSectorRepository : ICorporateSectorRepository
    {
        private readonly CDMDBContext _context;

        public CorporateSectorRepository(CDMDBContext context)
        {
            _context = context;
        }

        public async Task<CorporateSector> FindByDescription(string corporateSector)
        {
            return await _context.CorporateSectors.FirstAsync(x => x.Description == corporateSector);
        }

        public async Task<IList<CorporateSector>> GetAll()
        {
            return await _context.CorporateSectors.AsNoTracking().ToListAsync();
        }

        public async Task<CorporateSector> GetById(int corporateSectorId)
        {
            return await _context.CorporateSectors.FirstAsync(x => x.Id == corporateSectorId);
        }
    }
}
