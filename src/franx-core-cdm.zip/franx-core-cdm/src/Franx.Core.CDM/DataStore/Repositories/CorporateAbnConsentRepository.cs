using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;

namespace Franx.Core.CDM.DataStore.Repositories;

public class CorporateAbnConsentRepository : ICorporateAbnConsentRepository
{
    private readonly CDMDBContext _context;

    public CorporateAbnConsentRepository(CDMDBContext context)
    {
        _context = context;
    }

    public Task<CorporateAbnConsent?> GetLatestByCorporateIdAsync(int corporateId, CancellationToken cancellationToken)
    {
        return _context.CorporateAbnConsents
            .AsNoTracking()
            .Where(c => c.CorporateId == corporateId)
            .OrderByDescending(c => c.Id)
            .FirstOrDefaultAsync(cancellationToken);
    }
}
