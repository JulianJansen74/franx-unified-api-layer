﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;

namespace Franx.Core.CDM.DataStore.Repositories
{
    public interface ISegmentRepository
    {
        Task<IList<Segment>> GetAll();
    }
}
