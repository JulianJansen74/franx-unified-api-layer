﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;

namespace Franx.Core.CDM.DataStore.Repositories;

public interface ILegalActivityRepository
{
    Task<LegalActivity?> GetBySbiCode(string sbiCode);
    Task<LegalActivity?> GetById(int id, CancellationToken cancellationToken = default);
    Task<IList<LegalActivity>> GetAll(CancellationToken cancellationToken = default);
    Task Add(LegalActivity legalActivity, CancellationToken cancellationToken = default);
    Task Update(LegalActivity legalActivity, CancellationToken cancellationToken = default);
}
