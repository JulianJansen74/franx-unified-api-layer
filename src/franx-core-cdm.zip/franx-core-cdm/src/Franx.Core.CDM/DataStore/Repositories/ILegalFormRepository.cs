﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;

namespace Franx.Core.CDM.DataStore.Repositories;

public interface ILegalFormRepository
{
    Task<LegalForm> GetById(int id, CancellationToken cancellationToken = default);
    Task<LegalForm?> GetByName(string name, CancellationToken cancellationToken = default);
    Task<IList<LegalForm>> GetAll(CancellationToken cancellationToken = default);
    Task Add(LegalForm legalForm, CancellationToken cancellationToken = default);
    Task Update(LegalForm legalForm, CancellationToken cancellationToken = default);
}
