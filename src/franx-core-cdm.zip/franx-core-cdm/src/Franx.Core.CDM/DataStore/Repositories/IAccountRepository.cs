﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Franx.Core.CDM.Models;
using Franx.Core.CDM.Models.Reporting;

namespace Franx.Core.CDM.DataStore.Repositories;

public interface IAccountRepository
{
    Task Add(Account account);
    Task<IReadOnlyCollection<Account>> GetByPortfolioId(int portfolioId);
    Task<Account?> GetByNumber(string number);
    Task<Account?> GetByAccountNumber(string accountNumber);
}
