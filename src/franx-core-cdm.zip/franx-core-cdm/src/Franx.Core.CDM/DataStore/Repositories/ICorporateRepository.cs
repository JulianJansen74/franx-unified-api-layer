﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Franx.Core.CDM.Models;

namespace Franx.Core.CDM.DataStore.Repositories;

public interface ICorporateRepository
{
    void Add(Corporate corporate);
    Task<Corporate?> GetByBCNumber(long? bcNumber);
    Task<Corporate?> GetById(int corporateId, CancellationToken cancellationToken);
    Task<int?> GetCorporateIdByPortfolioId(int portfolioId, CancellationToken cancellationToken);
    Task<IEnumerable<Corporate>> GetChunk(int skip, int take);
}
