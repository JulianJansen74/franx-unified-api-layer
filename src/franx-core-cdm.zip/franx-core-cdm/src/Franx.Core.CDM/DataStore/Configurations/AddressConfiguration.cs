﻿using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations;

public class AddressConfiguration : IEntityTypeConfiguration<Address>
{
    public void Configure(EntityTypeBuilder<Address> builder)
    {
        builder.ToTable("Addresses");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
            .UseIdentityColumn(Constants.IdentitySeed);

        builder.Property(x => x.AddressLine1)
               .HasMaxLength(Constants.MaxLength.Address.AddressLine1)
               .IsRequired();

        builder.Property(x => x.AddressLine2)
               .HasMaxLength(Constants.MaxLength.Address.AddressLine2);

        builder.Property(x => x.HouseNumber)
               .HasMaxLength(Constants.MaxLength.Address.HouseNumber);

        builder.Property(x => x.ZipCode)
               .HasMaxLength(Constants.MaxLength.Address.ZipCode);

        builder.Property(x => x.City)
               .HasMaxLength(Constants.MaxLength.Address.City);

        builder.Property(x => x.Country)
               .HasMaxLength(Constants.MaxLength.Address.Country);

        builder.Property(x => x.Type)
               .IsRequired();

        builder.Property(x => x.Created)
            .HasDefaultValueSql("getdate()")
            .IsRequired();

        builder.Property(x => x.Modified)
            .HasDefaultValueSql("getdate()")
            .IsRequired();

        builder.Property(x => x.CreatedBy)
            .HasMaxLength(Constants.MaxLength.CreatedBy);

        builder.Property(x => x.ModifiedBy)
            .HasMaxLength(Constants.MaxLength.ModifiedBy);

        builder.HasIndex(r => new
        {
            r.CorporateId,
            r.Type
        }).IsUnique();
    }
}
