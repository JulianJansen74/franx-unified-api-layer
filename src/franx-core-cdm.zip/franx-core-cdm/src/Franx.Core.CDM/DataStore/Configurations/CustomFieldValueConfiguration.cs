﻿using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations
{
    public class CustomFieldValueConfiguration : IEntityTypeConfiguration<CustomFieldValue>
    {
        public void Configure(EntityTypeBuilder<CustomFieldValue> builder)
        {
            builder.ToTable("CustomFieldValues");
            builder.HasKey(x => x.Id);

            builder.Property(x => x.Id)
                    .UseIdentityColumn();

            builder.Property(x => x.Value)
               .IsRequired();

            builder.Property(x => x.CorporateId)
               .IsRequired();

            builder.HasOne(p => p.CustomField)
                .WithMany()
                .OnDelete(DeleteBehavior.Restrict)
                .HasForeignKey(p => p.CustomFieldId)
                .IsRequired(true);

            builder.Property(x => x.Created)
                .HasDefaultValueSql("getdate()")
                .IsRequired();

            builder.Property(x => x.Modified)
                .HasDefaultValueSql("getdate()")
                .IsRequired();

            builder.Property(x => x.CreatedBy)
                .HasMaxLength(Constants.MaxLength.CreatedBy);

            builder.Property(x => x.ModifiedBy)
                .HasMaxLength(Constants.MaxLength.ModifiedBy);
        }
    }
}
