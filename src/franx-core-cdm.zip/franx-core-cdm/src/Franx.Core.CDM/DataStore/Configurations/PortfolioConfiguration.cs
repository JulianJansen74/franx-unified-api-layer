﻿using Franx.Core.CDM.DataStore.Convertors;
using Franx.Core.CDM.Entities;
using Franx.Core.CDM.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations;

#nullable disable
public class PortfolioConfiguration : IEntityTypeConfiguration<Portfolio>
{
    public void Configure(EntityTypeBuilder<Portfolio> builder)
    {
        builder.ToTable("Portfolios");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
                .UseIdentityColumn(Constants.IdentitySeed);

        builder.HasOne(p => p.Corporate)
                .WithMany()
                .OnDelete(DeleteBehavior.Restrict)
                .HasForeignKey(p => p.CorporateId)
                .IsRequired(true);

        builder.Property(x => x.Name)
               .HasMaxLength(Constants.MaxLength.Portfolio.Name)
               .IsRequired();

        builder.Property(x => x.NominatedAccount)
               .HasMaxLength(Constants.MaxLength.Portfolio.NominatedAccount)
               .IsRequired();

        builder.Property(x => x.Created)
            .HasDefaultValueSql("getdate()")
            .IsRequired();

        builder.Property(x => x.Modified)
            .HasDefaultValueSql("getdate()")
            .IsRequired();
        
        builder.Property(x => x.BackofficeId)
            .HasDefaultValue(Backoffice.Matrix)
            .IsRequired();

        builder.HasIndex(x => new { x.CorporateId, x.Name })
            .IsUnique();

        builder.Property(x => x.CreatedBy)
            .HasMaxLength(Constants.MaxLength.CreatedBy);

        builder.Property(x => x.ModifiedBy)
            .HasMaxLength(Constants.MaxLength.ModifiedBy);

        builder.Property(x => x.Version)
            .IsRowVersion()
            .HasConversion(new RowVersionToStringConverter());
    }
}
#nullable enable
