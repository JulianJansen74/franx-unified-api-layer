﻿using System.Collections.Generic;
using Franx.Core.CDM.DataStore.Convertors;
using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations;

#nullable disable
public class CorporateConfiguration : IEntityTypeConfiguration<Corporate>
{
    public void Configure(EntityTypeBuilder<Corporate> builder)
    {
        builder.ToTable("Corporates");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
                .UseIdentityColumn(Constants.IdentitySeed);

        builder.HasMany(p => p.LegalActivities)
                .WithMany(p => p.Corporates)
                .UsingEntity<Dictionary<string, object>>(
                    "CorporateLegalActivities",
                    j => j
                        .HasOne<LegalActivity>()
                        .WithMany()
                        .HasForeignKey("LegalActivityId")
                        .OnDelete(DeleteBehavior.Cascade),
                    j => j
                        .HasOne<Corporate>()
                        .WithMany()
                        .HasForeignKey("CorporateId")
                        .OnDelete(DeleteBehavior.ClientCascade));

        builder.HasOne(p => p.CorporateSector)
                .WithMany()
                .OnDelete(DeleteBehavior.Restrict)
                .HasForeignKey(p => p.CorporateSectorId)
                .IsRequired(false);

        builder.HasOne(p => p.Segment)
                .WithMany()
                .OnDelete(DeleteBehavior.Restrict)
                .HasForeignKey(p => p.SegmentId)
                .IsRequired(false);

        builder.HasOne(p => p.LegalForm)
                .WithMany()
                .OnDelete(DeleteBehavior.Restrict)
                .HasForeignKey(p => p.LegalFormId)
                .IsRequired(false);

        builder.HasOne(p => p.PlattformSettings)
            .WithOne()
            .HasForeignKey<PlattformSettings>(p => p.Id);

        builder.Property(x => x.ClientFileId)
               .HasMaxLength(Constants.MaxLength.Corporate.ClientFileId)
               .IsRequired(false);

        builder.Property(x => x.Name)
               .HasMaxLength(Constants.MaxLength.Corporate.Name)
               .IsRequired();

        builder.Property(x => x.CountryOfIncorporation)
               .HasMaxLength(Constants.MaxLength.Corporate.CountryOfIncorporation)
               .IsRequired();

        builder.Property(x => x.LeiCode)
            .HasMaxLength(Constants.MaxLength.Corporate.LeiCode);

        builder.Property(x => x.LeiStatus);

        builder.Property(x => x.LeiExpiryDate);

        builder.Property(x => x.Email)
            .HasMaxLength(Constants.MaxLength.Corporate.Email);

        builder.Property(x => x.PhoneNumber)
            .HasMaxLength(Constants.MaxLength.Corporate.PhoneNumber);

        builder.Property(x => x.Status)
               .IsRequired();

        builder.Property(x => x.RegistrationNumber)
               .HasMaxLength(Constants.MaxLength.Corporate.RegistrationNumber)
               .IsRequired();

        builder.HasMany(p => p.Addresses)
            .WithOne()
            .HasForeignKey(a => a.CorporateId)
            .IsRequired();

        builder.HasMany(p => p.TaxCountries)
            .WithOne()
            .HasForeignKey(a => a.CorporateId)
            .IsRequired();


        builder.HasMany(p => p.CustomFieldValues)
            .WithOne()
            .HasForeignKey(a => a.CorporateId)
            .IsRequired();

        builder.HasIndex(x => x.ClientFileId)
            .IsUnique();

        builder.Property(x => x.BlancoPartyId)
            .HasMaxLength(Constants.MaxLength.BlancoPartyId)
            .IsRequired(false);

        builder.Property(x => x.Created)
            .HasDefaultValueSql("getdate()")
            .IsRequired();

        builder.Property(x => x.Modified)
            .HasDefaultValueSql("getdate()")
            .IsRequired();

        builder.Property(x => x.CreatedBy)
            .HasMaxLength(Constants.MaxLength.CreatedBy);

        builder.Property(x => x.ModifiedBy)
            .HasMaxLength(Constants.MaxLength.ModifiedBy);

        builder.HasIndex(x => x.BCNumber)
            .IsUnique()
            .HasFilter("BCNumber IS NOT NULL");

        builder.Property(x => x.Version)
            .IsRowVersion()
            .HasConversion(new RowVersionToStringConverter());
    }
}
#nullable enable
