﻿using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations;

public class AccountConfiguration : IEntityTypeConfiguration<Account>
{
    public void Configure(EntityTypeBuilder<Account> builder)
    {
        builder.ToTable("Accounts");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
            .UseIdentityColumn(Constants.IdentitySeed);

        builder.Property(x => x.Number)
            .HasMaxLength(Constants.MaxLength.Account.Number)
            .IsRequired();

        builder.HasIndex(x => x.Number).IsUnique();

        builder.HasIndex(x => new { x.PortfolioId, x.Type })
            .HasFilter("[type] <> " + (int)Models.AccountType.Internal)
            .IsUnique();

        builder.HasOne(account => account.Portfolio)
                .WithMany(portfolio => portfolio.Accounts)
                .OnDelete(DeleteBehavior.Restrict)
                .HasForeignKey(account => account.PortfolioId)
                .IsRequired(true);

        builder.Property(x => x.Created)
            .HasDefaultValueSql("getdate()")
            .IsRequired();

        builder.Property(x => x.Modified)
            .HasDefaultValueSql("getdate()")
            .IsRequired();

        builder.Property(x => x.CreatedBy)
            .HasMaxLength(Constants.MaxLength.CreatedBy);

        builder.Property(x => x.ModifiedBy)
            .HasMaxLength(Constants.MaxLength.ModifiedBy);
    }
}
