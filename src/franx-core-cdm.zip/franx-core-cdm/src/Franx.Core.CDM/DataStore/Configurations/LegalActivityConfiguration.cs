﻿using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations;

public class LegalActivityConfiguration : IEntityTypeConfiguration<LegalActivity>
{
    public void Configure(EntityTypeBuilder<LegalActivity> builder)
    {
        builder.ToTable("LegalActivities");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
                .UseIdentityColumn();

        builder.Property(x => x.Description)
               .HasMaxLength(Constants.MaxLength.DefaultDescriptionField)
               .IsRequired();

        builder.Property(x => x.SbiCode)
               .HasMaxLength(Constants.MaxLength.LegalActivity.SbiCode)
               .IsRequired();

        builder.HasIndex(x => x.SbiCode)
            .IsUnique();
    }
}
