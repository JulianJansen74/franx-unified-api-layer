﻿using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations
{
    public class CustomFieldConfiguration : IEntityTypeConfiguration<CustomField>
    {
        public void Configure(EntityTypeBuilder<CustomField> builder)
        {
            builder.ToTable("CustomFields");
            builder.HasKey(x => x.Id);

            builder.Property(x => x.Id)
                    .UseIdentityColumn();

            builder.Property(x => x.Code)
               .HasMaxLength(Constants.MaxLength.CustomField.Code)
               .IsRequired();

            builder.Property(x => x.Name)
               .HasMaxLength(Constants.MaxLength.DefaultDescriptionField)
               .IsRequired();

            builder.Property(x => x.ValueType)
               .IsRequired();

            builder.Property(x => x.Required)
               .IsRequired();
        }
    }
}
