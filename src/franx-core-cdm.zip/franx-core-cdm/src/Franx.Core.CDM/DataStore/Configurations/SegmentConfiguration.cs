﻿using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations;

public class SegmentConfiguration : IEntityTypeConfiguration<Segment>
{
    public void Configure(EntityTypeBuilder<Segment> builder)
    {
        builder.ToTable("Segments");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
                .UseIdentityColumn();

        builder.Property(x => x.Code)
               .HasMaxLength(Constants.MaxLength.Segment.Code)
               .IsRequired();

        builder.Property(x => x.Description)
               .HasMaxLength(Constants.MaxLength.DefaultDescriptionField)
               .IsRequired();

        builder.HasIndex(x => x.Code)
            .IsUnique();
    }
}
