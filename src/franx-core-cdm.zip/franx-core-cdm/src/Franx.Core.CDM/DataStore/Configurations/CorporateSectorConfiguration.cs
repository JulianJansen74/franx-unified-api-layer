﻿using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations;

public class CorporateSectorConfiguration : IEntityTypeConfiguration<CorporateSector>
{
    public void Configure(EntityTypeBuilder<CorporateSector> builder)
    {
        builder.ToTable("CorporateSectors");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
                .UseIdentityColumn();

        builder.Property(x => x.ExternalBusinessKey)
               .HasMaxLength(Constants.MaxLength.CorporateSector.ExternalBusinessKey)
               .IsRequired();

        builder.Property(x => x.Description)
               .HasMaxLength(Constants.MaxLength.DefaultDescriptionField)
               .IsRequired();

        builder.HasIndex(x => x.ExternalBusinessKey)
            .IsUnique();
    }
}
