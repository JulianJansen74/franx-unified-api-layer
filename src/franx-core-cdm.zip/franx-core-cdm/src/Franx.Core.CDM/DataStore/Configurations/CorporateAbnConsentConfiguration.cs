using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Franx.Core.CDM.DataStore.Configurations;

public class CorporateAbnConsentConfiguration : IEntityTypeConfiguration<CorporateAbnConsent>
{
    public void Configure(EntityTypeBuilder<CorporateAbnConsent> builder)
    {
        builder.ToTable("CorporateABNConsent");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
            .UseIdentityColumn(Constants.IdentitySeed);

        builder.Property(x => x.ClientId)
            .HasColumnName("Client-Id")
            .HasMaxLength(Constants.MaxLength.CorporateAbnConsent.ClientId)
            .IsRequired();

        builder.Property(x => x.ApiKey)
            .HasColumnName("API-Key")
            .HasMaxLength(Constants.MaxLength.CorporateAbnConsent.ApiKey)
            .IsRequired();

        builder.Property(x => x.Status)
            .HasConversion(new EnumToStringConverter<AbnConsentStatus>())
            .HasMaxLength(Constants.MaxLength.CorporateAbnConsent.Status)
            .IsRequired()
            .HasDefaultValue(AbnConsentStatus.Valid);

        builder.HasOne<Corporate>()
            .WithMany()
            .HasForeignKey(x => x.CorporateId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Property(x => x.Created)
            .HasDefaultValueSql("getdate()")
            .IsRequired();

        builder.Property(x => x.CreatedBy)
            .HasMaxLength(Constants.MaxLength.CreatedBy)
            .IsRequired();

        builder.Property(x => x.Modified)
            .HasDefaultValueSql("getdate()");

        builder.Property(x => x.ModifiedBy)
            .HasMaxLength(Constants.MaxLength.ModifiedBy);
    }
}
