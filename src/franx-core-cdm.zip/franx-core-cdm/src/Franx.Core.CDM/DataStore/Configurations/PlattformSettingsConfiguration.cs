﻿using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations;

public class PlattformSettingsConfiguration : IEntityTypeConfiguration<PlattformSettings>
{
    public void Configure(EntityTypeBuilder<PlattformSettings> builder)
    {
        builder.ToTable("PlattformSettings");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.PreferredLanguage)
              .HasMaxLength(Constants.MaxLength.Corporate.PreferredLanguage)
              .IsRequired();

        builder.Property(x => x.ExpectedYarlyVolumeTrade)
               .HasColumnType("decimal(18, 4)")
               .IsRequired();

        builder.Property(x => x.FxDerivativeEnabled)
               .IsRequired();

        builder.Property(x => x.TierId)
               .IsRequired();

        builder.Property(x => x.SubTierId)
               .IsRequired();

        builder.Property(x => x.DualSigningEnabled)
               .IsRequired();

        builder.Property(x => x.DualSigningThreshold)
            .HasColumnType("decimal(18, 4)");

        builder.Property(x => x.Created)
            .HasDefaultValueSql("getdate()")
            .IsRequired();

        builder.Property(x => x.Modified)
            .HasDefaultValueSql("getdate()")
            .IsRequired();

        builder.Property(x => x.CreatedBy)
            .HasMaxLength(Constants.MaxLength.CreatedBy);

        builder.Property(x => x.ModifiedBy)
            .HasMaxLength(Constants.MaxLength.ModifiedBy);
    }
}

