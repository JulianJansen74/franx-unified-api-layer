﻿using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations;

public class LegalFormConfiguration : IEntityTypeConfiguration<LegalForm>
{
    public void Configure(EntityTypeBuilder<LegalForm> builder)
    {
        builder.ToTable("LegalForms");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
               .UseIdentityColumn();

        builder.Property(x => x.Code)
               .IsRequired();

        builder.Property(x => x.ShortCode)
               .HasMaxLength(Constants.MaxLength.DefaultDescriptionField)
               .IsRequired(false);

        builder.Property(x => x.CountryCode)
               .HasMaxLength(Constants.MaxLength.DefaultDescriptionField)
               .IsRequired(false);

        builder.Property(x => x.Name)
               .HasMaxLength(Constants.MaxLength.DefaultDescriptionField)
               .IsRequired();

        builder.HasIndex(x => x.Code)
            .IsUnique();
    }
}
