﻿using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Franx.Core.CDM.DataStore.Configurations;

#nullable disable
public class CorporateTaxCountryConfiguration : IEntityTypeConfiguration<CorporateTaxCountry>
{
    public void Configure(EntityTypeBuilder<CorporateTaxCountry> builder)
    {
        builder.ToTable("CorporateTaxCountries");
        builder.Property(x => x.TaxNumber)
            .HasMaxLength(Constants.MaxLength.CorporateTaxCountry.TaxNumber);
        builder.Property(x => x.CountryCode)
            .HasMaxLength(Constants.MaxLength.CorporateTaxCountry.CountryCode);
        builder.HasIndex(x => new { x.CorporateId, x.CountryCode, x.TaxNumber }, "Ix_Unique_CorporateTax").IsUnique();
    }
}
#nullable enable
