﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace Franx.Core.CDM.DataStore.Interceptors;

[ExcludeFromCodeCoverage]
public static class DbInterceptorFactory
{
    public static IEnumerable<IInterceptor> CreateInterceptors(string connectionString)
    {
        var connectionStringBuilder = new SqlConnectionStringBuilder(connectionString);
        var requiresAzureToken = connectionStringBuilder.DataSource.Contains("database.windows.net")
                && string.IsNullOrEmpty(connectionStringBuilder.UserID)
                && string.IsNullOrEmpty(connectionStringBuilder.Password);

        if (requiresAzureToken)
            yield return new AzureDbConnectionInterceptor();
    }
}
