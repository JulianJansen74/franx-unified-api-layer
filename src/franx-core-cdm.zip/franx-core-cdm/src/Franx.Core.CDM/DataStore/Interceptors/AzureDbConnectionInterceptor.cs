﻿using System.Data.Common;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using Azure.Core;
using Azure.Identity;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace Franx.Core.CDM.DataStore.Interceptors;

[ExcludeFromCodeCoverage]
public class AzureDbConnectionInterceptor : DbConnectionInterceptor
{
    public override InterceptionResult ConnectionOpening(DbConnection connection, ConnectionEventData eventData, InterceptionResult result)
    {
        if (connection is Microsoft.Data.SqlClient.SqlConnection conn)
        {
            var azureCredential = new DefaultAzureCredential(new DefaultAzureCredentialOptions { ExcludeEnvironmentCredential = true });
            var accessToken = azureCredential.GetToken(new TokenRequestContext(new[] { "https://database.windows.net/.default" }));
            conn.AccessToken = accessToken.Token;
        }

        return base.ConnectionOpening(connection, eventData, result);
    }

    public override async ValueTask<InterceptionResult> ConnectionOpeningAsync(DbConnection connection, ConnectionEventData eventData, InterceptionResult result,
        CancellationToken cancellationToken = new CancellationToken())
    {
        if (connection is Microsoft.Data.SqlClient.SqlConnection conn)
        {
            var azureCredential = new DefaultAzureCredential(new DefaultAzureCredentialOptions { ExcludeEnvironmentCredential = true });
            var accessToken = await azureCredential.GetTokenAsync(new TokenRequestContext(new[] { "https://database.windows.net/.default" }), cancellationToken);
            conn.AccessToken = accessToken.Token;
        }

        return await base.ConnectionOpeningAsync(connection, eventData, result, cancellationToken);
    }
}
