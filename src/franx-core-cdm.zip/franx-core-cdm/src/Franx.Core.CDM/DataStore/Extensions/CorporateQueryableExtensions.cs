﻿using System.Linq;
using Franx.Core.CDM.Entities;
using Microsoft.EntityFrameworkCore;

namespace Franx.Core.CDM.DataStore.Extensions
{
    public static class CorporateQueryableExtensions
    {
        public static IQueryable<Corporate> IncludeAll(this IQueryable<Corporate> query)
        {
            return query
                .Include(c => c.LegalForm)
                .Include(c => c.Addresses)
                .Include(c => c.LegalActivities)
                .Include(c => c.PlattformSettings)
                .Include(c => c.CustomFieldValues)
                .Include(c => c.TaxCountries);
        }
    }
}
