﻿using System;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Franx.Core.CDM.DataStore.Convertors;

public class RowVersionToStringConverter : ValueConverter<string, byte[]>
{
    public RowVersionToStringConverter()
        : base(
            stringValue => BitConverter.GetBytes(ulong.Parse(stringValue)),
            byteValue => BitConverter.ToUInt64(byteValue).ToString())
    { }
}
