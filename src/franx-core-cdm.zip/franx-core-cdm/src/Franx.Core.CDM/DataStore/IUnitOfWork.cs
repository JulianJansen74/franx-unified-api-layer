﻿using System.Threading.Tasks;

namespace Franx.Core.CDM.DataStore;

public interface IUnitOfWork
{
    Task SaveChangesAsync();
}
