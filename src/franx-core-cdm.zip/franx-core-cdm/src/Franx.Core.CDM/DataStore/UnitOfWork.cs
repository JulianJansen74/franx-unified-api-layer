﻿using System.Threading.Tasks;

namespace Franx.Core.CDM.DataStore;

public class UnitOfWork : IUnitOfWork
{
    private readonly CDMDBContext _context;

    public UnitOfWork(CDMDBContext context)
    {
        _context = context;
    }

    public async Task SaveChangesAsync()
    {
        await _context.SaveChangesAsync();
    }
}
