﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace Franx.Core.CDM.Helper
{
    public static class SerializerOptions
    {
        public static JsonSerializerOptions DefaultSettings = new()
        {
            PropertyNameCaseInsensitive = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            Converters = { new JsonStringEnumConverter() }
        };
    }
}
