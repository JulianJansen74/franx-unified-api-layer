using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.DataStore.Repositories;
using Franx.Core.CDM.Entities;
using Franx.Core.CDM.Exceptions;
using Franx.Core.CDM.Models;

namespace Franx.Core.CDM.Services
{
    public class CorporateService : ICorporateService
    {
        private readonly IAccountService _accountService;
        private readonly ICorporateAbnConsentRepository _corporateAbnConsentRepository;

        public CorporateService(
            IAccountService accountService,
            ICorporateAbnConsentRepository corporateAbnConsentRepository
            )
        {
            _accountService = accountService;
            _corporateAbnConsentRepository = corporateAbnConsentRepository;
        }

      
        public async Task<CorporateAbnConsentDto> GetAbnConsentByAccountNumber(string accountNumber, CancellationToken cancellationToken)
        {
            var account = await _accountService.GetByAccountNumber(accountNumber);
            if (account is null)
                throw new DataNotFoundException($"Account is not found for {accountNumber}");

            var consent = await _corporateAbnConsentRepository.GetLatestByCorporateIdAsync(account.CorporateId, cancellationToken);
            if (consent is null)
                throw new DataNotFoundException($"ABN consent is not found for corporate {account.CorporateId}");

            if (consent.Status != AbnConsentStatus.Valid)
                throw new AbnConsentInvalidStatusException(consent.Status);

            return new CorporateAbnConsentDto
            {
                ClientId = consent.ClientId,
                ApiKey = consent.ApiKey
            };
        }
        
   }
}
