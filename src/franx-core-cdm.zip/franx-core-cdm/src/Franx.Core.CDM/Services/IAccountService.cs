﻿using System.Threading.Tasks;
using Franx.Core.CDM.Models.Reporting;

namespace Franx.Core.CDM.Services
{
    public interface IAccountService
    {
        Task<AccountReport?> GetByAccountNumber(string accountNumber);
    }
}
