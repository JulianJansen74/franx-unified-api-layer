using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Models;

namespace Franx.Core.CDM.Services
{
    public interface ICorporateService
    {
        Task<CorporateAbnConsentDto> GetAbnConsentByAccountNumber(string accountNumber,
            CancellationToken cancellationToken);
    }
}
