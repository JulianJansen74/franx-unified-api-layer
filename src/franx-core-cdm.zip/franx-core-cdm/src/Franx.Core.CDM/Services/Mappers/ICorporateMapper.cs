﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Franx.Core.CDM.Models;
using Franx.Core.CDM.Services.UserApi.Models;

namespace Franx.Core.CDM.Services.Mappers
{
    public interface ICorporateMapper
    {
        Task<CorporateInfo> MapTo(Corporate corporate, IReadOnlyCollection<Account>? accounts, List<UserInfo>? personInfos,
            CorporateInfoRequest corporateInfoRequest, CDM.Models.Reporting.PortfolioReport portfolio);

        CorporateDetails ToCorporateDetails(Entities.Corporate corporate, CorporateOverviewConfiguration configuration);
    }
}
