﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Franx.Core.CDM.Entities;
using Franx.Core.CDM.Models;
using Franx.Core.CDM.Services.UserApi.Models;

namespace Franx.Core.CDM.Services.Mappers
{
    public class CorporateMapper : ICorporateMapper
    {

        public async Task<CorporateInfo> MapTo(Corporate corporate, IReadOnlyCollection<Account>? accounts, List<UserInfo>? personInfos,
            CorporateInfoRequest corporateInfoRequest, Models.Reporting.PortfolioReport portfolio)
        {
            return new CorporateInfo
            {
                Name = corporate.Name,
                Addresses = corporateInfoRequest.IncludeAddresses ? await ConvertAddresses(corporate.Addresses) : null,
                Definitions = new CorporateInfoDefinitions
                {
                    PortfolioName = portfolio.PortfolioName,
                    PortfolioId = portfolio.PortfolioId,
                    Backoffice = portfolio.Backoffice,
                    DualSigningThreshold = corporate.PlattformSettings.DualSigningEnabled ?
                        (corporate.PlattformSettings.DualSigningThreshold ?? 0m) : default(decimal?),
                    DualSigningEnabled = corporate.PlattformSettings.DualSigningEnabled,
                    HardBalanceCheckIM = corporate.PlattformSettings.HardBalanceCheckIM,
                    TierId = corporate.PlattformSettings.TierId,
                    SubTierId = corporate.PlattformSettings.SubTierId
                },
                Details = new CorporateInfoDetails
                {
                    CountryCode = corporateInfoRequest.IncludeCountryCode ? corporate.CountryOfIncorporation : null,
                    AccountNumber = accounts?.FirstOrDefault(x => x.Type == AccountType.Bban)?.Number,
                    Iban = accounts?.FirstOrDefault(x => x.Type == AccountType.Iban)?.Number,
                    InitialMarginAccountNumber = accounts?.FirstOrDefault(x => x.Type == AccountType.InitialMargin)?.Number,
                    VariationMarginAccountNumber = accounts?.FirstOrDefault(x => x.Type == AccountType.VariationMargin)?.Number,
                    NominatedAccount = portfolio.NominatedAccount
                },
                Id = corporate.Id,
                Lei = GetLeiInformation(corporate),
                Persons = personInfos?.Select(x => new PersonIdentifier { Id = x.Id.ToString(), Name = $"{x.FirstName} {x.LastName}" }).ToArray(),
                Status = corporate.Status.ToString(),
                Email = corporate.Email,
                PreferredLanguage = corporate.PlattformSettings.PreferredLanguage,
                FxDerivativeEnabled = corporate.PlattformSettings.FxDerivativeEnabled,
                AccountFee = corporate.AccountFee,
                AccountFeeAmount = corporate.AccountFeeAmount
            };
        }

        private LeiInfo? GetLeiInformation(Corporate corporate)
        {
            LeiInfo? leiInfo = null;
            if (!string.IsNullOrEmpty(corporate.LeiCode) || corporate.LeiStatus != null || corporate.LeiExpiryDate != null)
            {
                leiInfo = new LeiInfo
                {
                    Code = corporate.LeiCode,
                    ExpiryDate = corporate.LeiExpiryDate,
                    Status = corporate.LeiStatus.HasValue ? corporate.LeiStatus.Value.ToString() : string.Empty
                };
            }

            return leiInfo;
        }

        public CorporateDetails ToCorporateDetails(Entities.Corporate corporate, CorporateOverviewConfiguration? configuration)
        {
            if (!Constants.Languages.TryGetValue(corporate.PlattformSettings.PreferredLanguage ?? string.Empty, out var languageName))
                languageName = "-";

            return new CorporateDetails
            {
                Address = ToAddressDto(corporate.Addresses.FirstOrDefault(x => x.Type == AddressType.Registered)),
                CorrespondenceAddress = ToAddressDto(corporate.Addresses.FirstOrDefault(x => x.Type == AddressType.Correspondence)),
                Id = corporate.Id,
                Name = corporate.Name,
                LegalForm = corporate.LegalForm != null ? new SelectOptionInt(corporate.LegalForm.Id, corporate.LegalForm.Name) : null,
                CountryOfIncorporation = corporate.CountryOfIncorporation,
                Email = corporate.Email,
                PhoneNumber = corporate.PhoneNumber,
                LeiExpiryDate = corporate.LeiExpiryDate,
                LeiNumber = corporate.LeiCode,
                LeiStatus = corporate.LeiStatus,
                RegistrationNumber = corporate.RegistrationNumber,
                Status = corporate.Status,
                PreferredLanguage = languageName,
                BlancoPartyId = corporate.BlancoPartyId,
                BCNumber = corporate.BCNumber,
                IncorporationDate = corporate.IncorporationDate,
                RiskClassification = corporate.RiskClassification,
                RiskClassifiedOn = corporate.RiskClassifiedOn,
                OnboardedOn = corporate.Created,
                MifidTestCompleted = corporate.MifidTestCompleted,
                OffboardedOn = corporate.Status is CorporateStatus.Offboarding or CorporateStatus.Closed ? corporate.Modified : default(DateTime?),
                FxDerivativeEnabled = corporate.PlattformSettings.FxDerivativeEnabled,
                IncludeImInVmExposure = corporate.PlattformSettings.IncludeImInVmExposure,
                Version = corporate.Version,
                CorporateConfiguration = configuration,
                AccountFee = corporate.AccountFee,
                AccountFeeAmount = corporate.AccountFeeAmount,
                LegalActivities = corporate.LegalActivities.Select(x => new CorporateDetails.LegalActivity
                {
                    Id = x.Id,
                    Code = x.SbiCode,
                    Description = x.Description
                }).ToArray(),
                TaxCountries = (corporate.TaxCountries ?? new List<Entities.CorporateTaxCountry>()).Select(x => new CorporateDetails.TaxCountryDetails
                {
                    Id = x.Id,
                    CountryCode = x.CountryCode,
                    TaxNumber = x.TaxNumber
                }).ToArray()
            };
        }
        
        private CorporateDetails.AddressDto? ToAddressDto(Address? address)
        {
            if (address == null)
                return null;

            return new CorporateDetails.AddressDto
            {
                AddressLine1 = address.AddressLine1,
                AddressLine2 = address.AddressLine2,
                City = address.City,
                Country = address.Country,
                HouseNumber = address.HouseNumber,
                Id = address.Id,
                Type = address.Type,
                ZipCode = address.ZipCode
            };
        }

        private static string ConvertAddressType(AddressType addressType)
        {
            return addressType switch
            {
                AddressType.Registered => "Registered Address",
                AddressType.Correspondence => "Correspondence",
                _ => throw new ArgumentOutOfRangeException(nameof(addressType), addressType, null)
            };
        }

        private async Task<AddressInfo[]?> ConvertAddresses(IList<Address> addresses)
        {
            var countryIsoCodes = addresses.Select(i => i.Country).Distinct().ToList();

            return addresses.Select(a => new AddressInfo
            {
                Type = ConvertAddressType(a.Type),
                Address1 = a.AddressLine1,
                Address2 = a.AddressLine2,
                Address3 = string.Empty,
                City = a.City,
                HouseNumber = a.HouseNumber,
                PostalCode = a.ZipCode,
                CountryCode = a.Country
            }).ToArray();
        }
    }
}
