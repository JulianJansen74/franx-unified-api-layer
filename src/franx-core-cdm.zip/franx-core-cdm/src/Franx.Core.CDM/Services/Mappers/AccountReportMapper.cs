﻿using Franx.Core.CDM.Entities;
using Franx.Core.CDM.Models.Reporting;

namespace Franx.Core.CDM.Services.Mappers;

public class AccountReportMapper : IAccountReportMapper
{
    public AccountReport MapTo(Account account)
    {
        return new AccountReport
        {
            AccountId = account.Id,
            Number = account.Number,
            Type = account.Type,
            Status = account.Status,
            PortfolioName = account.Portfolio.Name,
            PortfolioId = account.PortfolioId,
            CorporateId = account.Portfolio.CorporateId
        };
    }
}
