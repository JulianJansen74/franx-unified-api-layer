﻿using Franx.Core.CDM.Entities;
using Franx.Core.CDM.Models.Reporting;

namespace Franx.Core.CDM.Services.Mappers;

public interface IAccountReportMapper
{
    AccountReport MapTo(Account account);
}
