﻿using System.Threading.Tasks;
using Franx.Core.CDM.DataStore.Repositories;
using Franx.Core.CDM.Models.Reporting;
using Franx.Core.CDM.Services.Mappers;

namespace Franx.Core.CDM.Services
{
    public class AccountService : IAccountService
    {
        private readonly IAccountRepository _accountRepository;
        private readonly IAccountReportMapper _accountReportMapper;
        public AccountService(IAccountRepository accountRepository,
            IAccountReportMapper accountReportMapper)
        {
            _accountRepository = accountRepository;
            _accountReportMapper = accountReportMapper;
        }


        public async Task<AccountReport?> GetByAccountNumber(string accountNumber)
        {
            var account=await _accountRepository.GetByAccountNumber(accountNumber);
            return account == null ? null : _accountReportMapper.MapTo(account);
        }

    }
}
