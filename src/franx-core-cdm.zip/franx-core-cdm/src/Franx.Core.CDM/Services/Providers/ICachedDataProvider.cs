﻿using System;
using System.Threading.Tasks;

namespace Franx.Core.CDM.Services.Providers
{
    public interface ICachedDataProvider
    {
        Task<T> GetOrCreateAsync<T>(object key, Func<Task<T>> factory, DateTimeOffset expiration);
        Task<T> GetOrCreateAsync<T>(object key, Func<Task<T>> factory);
        string CreateKey(params object[] args);
    }
}
