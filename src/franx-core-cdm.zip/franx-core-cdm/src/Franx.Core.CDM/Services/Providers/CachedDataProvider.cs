﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;

namespace Franx.Core.CDM.Services.Providers
{
    public class CachedDataProvider : ICachedDataProvider
    {
        private const string KeyDelimiter = "-";

        private readonly IMemoryCache _cache;

        public CachedDataProvider(IMemoryCache cache)
        {
            _cache = cache;
        }

        public async Task<T> GetOrCreateAsync<T>(object key, Func<Task<T>> factory)
        {
            return await GetOrCreateAsync(key, factory, DateTimeOffset.UtcNow.AddMinutes(15));
        }

        public async Task<T> GetOrCreateAsync<T>(object key, Func<Task<T>> factory, DateTimeOffset expiration)
        {
            return await _cache.GetOrCreateAsync(key, entry =>
            {
                entry.SetAbsoluteExpiration(expiration);
                return factory();
            });
        }

        public string CreateKey(params object[] args)
        {
            return string.Join(KeyDelimiter, args).ToUpperInvariant();
        }
    }
}
