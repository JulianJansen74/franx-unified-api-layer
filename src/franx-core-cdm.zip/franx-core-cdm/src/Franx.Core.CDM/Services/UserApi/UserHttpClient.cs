﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Services.UserApi.Models;
using Microsoft.Extensions.Logging;

namespace Franx.Core.CDM.Services.UserApi
{
    public class UserHttpClient : IUserHttpClient
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<UserHttpClient> _logger;

        public UserHttpClient(HttpClient httpClient, ILogger<UserHttpClient> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
        }

        public async Task<List<UserInfo>?> GetUserInfo(int corporateId, CancellationToken cancellationToken)
        {
            var requestPath = $"/api/v1/user-info/corporate/{corporateId}";
            _logger.LogInformation("get user info from {path} for Id {corporateId}", requestPath, corporateId);

            var response =
                await _httpClient.GetAsync(requestPath,cancellationToken);

            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                _logger.LogInformation("user info from {path} for Id {corporateId} return not found", requestPath, corporateId);
                return null;
            }
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<UserInfo>>(cancellationToken: cancellationToken);
        }
    }
}
