﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Services.UserApi.Models;

namespace Franx.Core.CDM.Services.UserApi
{
    public interface IUserHttpClient
    {
        Task<List<UserInfo>?> GetUserInfo(int corporateId, CancellationToken cancellationToken);
    }
}
