﻿using System;

namespace Franx.Core.CDM.Services.UserApi.Models
{
    public class UserInfo
    {
        public Guid Id { get; set; }
        public int PersonId { get; set; }
        public string Role { get; set; }
        public string Salutation { get; set; }
        public string PreferredName { get; set; }
        public string Initials { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string MobilePhoneNumber { get; set; }
        public string PreferredLanguage { get; set; }
        public string Status { get; set; }
    }
}
