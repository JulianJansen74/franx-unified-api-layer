﻿using System.Text.Json.Serialization;

namespace Franx.Core.CDM.Services.StaticDataApi.Models
{
    public class StaticDataCountry
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("alphaShortCode")]
        public string Code { get; set; }
    }
}
