﻿namespace Franx.Core.CDM.Services.StaticDataApi.Models
{
    public class StaticDataCountryResponse
    {
        public StaticDataCountry[] Result { get; set; }
    }
}
