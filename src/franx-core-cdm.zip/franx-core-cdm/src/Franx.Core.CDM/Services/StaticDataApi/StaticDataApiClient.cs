﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Franx.Core.CDM.Services.StaticDataApi.Models;

namespace Franx.Core.CDM.Services.StaticDataApi
{
    public class StaticDataApiClient : IStaticDataApiClient
    {
        private readonly HttpClient _httpClient;

        public StaticDataApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<StaticDataCountryResponse> GetCountries()
        {
            var requestPath = "api/v1/schemas/Country/static-data/latest?PageSize=999";
            return await _httpClient.GetFromJsonAsync<StaticDataCountryResponse>(requestPath);
        }
    }
}
