﻿using System.Threading.Tasks;
using Franx.Core.CDM.Services.StaticDataApi.Models;

namespace Franx.Core.CDM.Services.StaticDataApi
{
    public interface IStaticDataApiClient
    {
        Task<StaticDataCountryResponse> GetCountries();
    }
}
