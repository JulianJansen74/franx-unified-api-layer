﻿using System;
using System.Net;

namespace Franx.Core.CDM.Exceptions
{
    public class PortfolioFoundException : Exception, IAppException
    {
        public PortfolioFoundException(string message) : base(message)
        {
        }

        public ErrorKey ErrorKey => ErrorKey.PortfolioFound;
        public HttpStatusCode HttpStatusCode => HttpStatusCode.BadRequest;
    }
}
