﻿using System;
using System.Net;

namespace Franx.Core.CDM.Exceptions
{
    public class CorporateNotFoundException : Exception, IAppException
    {
        public CorporateNotFoundException(string blancoId) : base($"No corporate found with blanco id {blancoId}")
        {
        }

        public ErrorKey ErrorKey => ErrorKey.CorporateNotFound;
        public HttpStatusCode HttpStatusCode => HttpStatusCode.NotFound;
    }
}
