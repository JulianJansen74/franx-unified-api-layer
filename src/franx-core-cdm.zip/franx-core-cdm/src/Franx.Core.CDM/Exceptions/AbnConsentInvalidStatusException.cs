using System;
using System.Net;
using Franx.Core.CDM.Entities;

namespace Franx.Core.CDM.Exceptions;

public sealed class AbnConsentInvalidStatusException : Exception, IAppException
{
    public AbnConsentInvalidStatusException(AbnConsentStatus status)
        : base(FormattableString.Invariant($"ABN consent status is {status}."))
    {
    }

    public ErrorKey ErrorKey => ErrorKey.AbnConsentInvalidStatus;
    public HttpStatusCode HttpStatusCode => HttpStatusCode.BadRequest;
}
