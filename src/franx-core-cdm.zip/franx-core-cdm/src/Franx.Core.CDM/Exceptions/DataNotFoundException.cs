﻿using System;
using System.Net;

namespace Franx.Core.CDM.Exceptions
{
    public class DataNotFoundException : Exception, IAppException
    {
        public DataNotFoundException(string message) : base(message)
        {
        }

        public ErrorKey ErrorKey => ErrorKey.DataNotFound;
        public HttpStatusCode HttpStatusCode => HttpStatusCode.NotFound;
    }
}
