﻿using System;
using System.Net;

namespace Franx.Core.CDM.Exceptions
{
    public class MultiplePortfoliosException: Exception, IAppException
    {
        public MultiplePortfoliosException(string message) : base(message)
        {
        }

        public ErrorKey ErrorKey => ErrorKey.MultiplePortfolios;
        public HttpStatusCode HttpStatusCode => HttpStatusCode.InternalServerError;
    }
}
