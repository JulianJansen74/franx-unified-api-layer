﻿using System;
using System.Net;

namespace Franx.Core.CDM.Exceptions
{
    public class CorporateFoundException : Exception, IAppException
    {
        public CorporateFoundException(string message) : base(message)
        {
        }

        public ErrorKey ErrorKey => ErrorKey.CorporateFound;
        public HttpStatusCode HttpStatusCode => HttpStatusCode.BadRequest;
    }
}
