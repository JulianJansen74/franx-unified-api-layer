﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Franx.Core.CDM.Exceptions
{
    public enum ErrorKey
    {
        UnhandledException,
        DataNotFound,
        BCNumberDuplicated,
        VersionMismatch,
        CorporateNotFound,
        MultiplePortfolios,
        PortfolioFound,
        CorporateFound,
        AbnConsentInvalidStatus
    }
}
