﻿using System;
using System.Net;

namespace Franx.Core.CDM.Exceptions;

public class BCNumberDuplicatedException : Exception, IAppException
{
    public BCNumberDuplicatedException() : base()
    {
    }

    public ErrorKey ErrorKey => ErrorKey.BCNumberDuplicated;
    public HttpStatusCode HttpStatusCode => HttpStatusCode.BadRequest;
}
