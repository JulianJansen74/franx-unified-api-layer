﻿using System;
using System.Net;

namespace Franx.Core.CDM.Exceptions;
public class VersionMisMatchException : Exception, IAppException
{
    public VersionMisMatchException(string entityType) : base($"The {entityType} Version is not correct. Please use latest version.")
    {
    }

    public ErrorKey ErrorKey => ErrorKey.VersionMismatch;
    public HttpStatusCode HttpStatusCode => HttpStatusCode.Conflict;
}
