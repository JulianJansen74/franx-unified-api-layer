﻿using System.Net;

namespace Franx.Core.CDM.Exceptions;

public interface IAppException
{
    public ErrorKey ErrorKey { get; }
    public HttpStatusCode HttpStatusCode { get; }
}
