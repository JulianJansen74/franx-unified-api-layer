using System.ComponentModel.DataAnnotations;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using Franx.Core.CDM.Api.Authorization;
using Franx.Core.CDM.Api.V1.Mappers;
using Franx.Core.CDM.Api.V1.Models;
using Franx.Core.CDM.Exceptions;
using Franx.Core.CDM.Models;
using Franx.Core.CDM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Franx.Core.CDM.Api.V1.Controllers;

[ApiController]
[Consumes(MediaTypeNames.Application.Json)]
[Produces(MediaTypeNames.Application.Json)]
[Route("api/v{version:apiVersion}/corporate-info")]
public class CorporateInfoController : ControllerBase
{
    private readonly ICorporateService _corporateService;
    private readonly ICorporateInfoMapper _corporateInfoMapper;

    public CorporateInfoController(
        ICorporateService corporateService,
        ICorporateInfoMapper corporateInfoMapper)
    {
        _corporateService = corporateService;
        _corporateInfoMapper = corporateInfoMapper;
    }

    [HttpGet("abn-consent")]
    [ProducesResponseType(statusCode: StatusCodes.Status200OK, type: typeof(CorporateAbnConsentDto))]
    [ProducesResponseType(statusCode: StatusCodes.Status404NotFound)]
    [ProducesResponseType(statusCode: StatusCodes.Status400BadRequest)]
    [Authorize(Policy = Roles.ReadCustomerData)]
    public async Task<IActionResult> GetAbnConsentByAccountNumber([FromQuery, Required] string accountNumber, CancellationToken cancellationToken)
    {
        try
        {
            return Ok(await _corporateService.GetAbnConsentByAccountNumber(accountNumber, cancellationToken));
        }
        catch (DataNotFoundException)
        {
            return NotFound();
        }
    }

}
