﻿using System;
using System.Collections.Generic;
using System.Linq;
using Franx.Core.CDM.Api.V1.Models;
using Franx.Core.CDM.Entities;
using Franx.Core.CDM.Models;

namespace Franx.Core.CDM.Api.V1.Mappers
{
    public class CorporateInfoMapper : ICorporateInfoMapper
    {
        public CorporateInfoRequest MapToInfoRequest(int corporateId, CorporateInfoApiRequest apiRequest)
        {
            return new CorporateInfoRequest
            {
                CorporateId = corporateId,
                IncludeAddresses = apiRequest.IncludeAddresses,
                IncludeCountryCode = apiRequest.IncludeCountryCode
            };
        }
    }
}
