﻿using Franx.Core.CDM.Api.V1.Models;
using Franx.Core.CDM.Models;

namespace Franx.Core.CDM.Api.V1.Mappers
{
    public interface ICorporateInfoMapper
    {
        CorporateInfoRequest MapToInfoRequest(int corporateId, CorporateInfoApiRequest apiRequest);
    }
}
