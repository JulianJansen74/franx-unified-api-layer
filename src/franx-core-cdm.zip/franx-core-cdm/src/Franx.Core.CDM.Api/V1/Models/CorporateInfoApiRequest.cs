﻿namespace Franx.Core.CDM.Api.V1.Models
{
    public class CorporateInfoApiRequest
    {
        public bool IncludeAddresses { get; set; }
        public bool IncludeCountryCode { get; set; }
    }
}
