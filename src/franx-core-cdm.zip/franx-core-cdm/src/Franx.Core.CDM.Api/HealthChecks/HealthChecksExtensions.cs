﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Franx.Core.CDM.DataStore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace Franx.Core.CDM.Api.HealthChecks
{
    [ExcludeFromCodeCoverage]
    public static class HealthChecksExtensions
    {
        public static List<string> Tags = new() { "essential" };
        public static IServiceCollection AddApiHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHealthChecks()
                .AddDbContextCheck<CDMDBContext>("cdm-database", tags: Tags);

            return services;
        }


        public static IApplicationBuilder UseApiHealthChecks(this IApplicationBuilder app)
        {
            app.UseHealthChecks("/api/system/status", new HealthCheckOptions
            {
                Predicate = x => x.Tags.Any(t => Tags.Contains(t))
            });

            app.UseHealthChecks("/api/system/status/details", new HealthCheckOptions
            {
                ResponseWriter = WriteHealthReport
            });

            return app;
        }

        private static Task WriteHealthReport(HttpContext httpContext, HealthReport result)
        {
            httpContext.Response.ContentType = "application/json";

            return httpContext.Response.WriteAsync(JsonSerializer.Serialize(result, new JsonSerializerOptions
            {
                WriteIndented = true,
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
                Converters = { new JsonStringEnumConverter() }
            }));
        }
    }
}
