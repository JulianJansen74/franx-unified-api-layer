using System.Diagnostics.CodeAnalysis;
using Franx.Core.CDM.Api.V1.Mappers;
using Franx.Core.CDM.DataStore;
using Franx.Core.CDM.DataStore.Repositories;
using Franx.Core.CDM.Services;
using Franx.Core.CDM.Services.Mappers;
using Franx.Core.CDM.Services.Providers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Franx.Core.CDM.Api
{
    [ExcludeFromCodeCoverage]
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection RegisterCdmApiDependencies(this IServiceCollection services)
        {
            services
                .AddProviders()
                .AddApiMappers()
                .AddServices()
                .AddDataStore();

            return services;
        }

        public static IServiceCollection AddProviders(this IServiceCollection services)
        {
            services.AddSingleton<ICachedDataProvider, CachedDataProvider>();

            return services;
        }

        public static IServiceCollection AddApiMappers(this IServiceCollection services)
        {
            services.TryAddScoped<ICorporateInfoMapper, CorporateInfoMapper>();
            services.TryAddSingleton<IAccountReportMapper, AccountReportMapper>();
            services.TryAddScoped<ICorporateMapper, CorporateMapper>();

            return services;
        }

        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.TryAddScoped<ICorporateService, CorporateService>();
            services.TryAddScoped<IAccountService, AccountService>();
            
            return services;
        }

        public static IServiceCollection AddDataStore(this IServiceCollection services)
        {
            services.TryAddScoped<IUnitOfWork, UnitOfWork>();
            services.TryAddScoped<ICorporateRepository, CorporateRepository>();
            services.TryAddScoped<ILegalActivityRepository, LegalActivityRepository>();
            services.TryAddScoped<ILegalFormRepository, LegalFormRepository>();
            services.TryAddScoped<IAccountRepository, AccountRepository>();
            services.TryAddScoped<ICustomFieldsRepository, CustomFieldsRepository>();
            services.TryAddScoped<ICorporateSectorRepository, CorporateSectorRepository>();
            services.TryAddScoped<ISegmentRepository, SegmentRepository>();
            services.TryAddScoped<ICorporateAbnConsentRepository, CorporateAbnConsentRepository>();

            return services;
        }
    }
}
