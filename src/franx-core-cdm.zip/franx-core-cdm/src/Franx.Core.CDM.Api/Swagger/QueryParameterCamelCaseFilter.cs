﻿using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace Franx.Core.CDM.Api.Swagger
{
    [ExcludeFromCodeCoverage]
    public class QueryParameterCamelCaseFilter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (operation?.Parameters != null)
            {
                foreach (OpenApiParameter parameter in operation.Parameters.Where(x => x.In == ParameterLocation.Query))
                {
                    parameter.Name = LowerCaseFirstLetter(parameter.Name);
                }
            }
        }

        private static string LowerCaseFirstLetter(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return input;
            }

            return char.ToLowerInvariant(input[0]) + input[1..];
        }
    }
}
