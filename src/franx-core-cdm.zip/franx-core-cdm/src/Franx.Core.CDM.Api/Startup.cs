﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json;
using System.Text.Json.Serialization;
using Franx.Context.AspNetCore;
using Franx.Context.AspNetCore.CorrelationId;
using Franx.Context.AspNetCore.UserInfo;
using Franx.Core.CDM.Api.Authorization;
using Franx.Core.CDM.Api.Extensions.AzureAdToken;
using Franx.Core.CDM.Api.HealthChecks;
using Franx.Core.CDM.Api.Middlewares;
using Franx.Core.CDM.Api.Swagger;
using Franx.Core.CDM.DataStore;
using Franx.Core.CDM.DataStore.Interceptors;
using Franx.Core.CDM.Services.StaticDataApi;
using Franx.Core.CDM.Services.UserApi;
using Franx.Validation.AspNetCore.Configuration;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Franx.Core.CDM.Api
{
    [ExcludeFromCodeCoverage]
    public class Startup
    {
        public Startup(IConfiguration configuration, IHostEnvironment hostEnvironment)
        {
            HostEnvironment = hostEnvironment;
            Configuration = configuration;
        }

        public IHostEnvironment HostEnvironment { get; }
        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
#if !DEBUG
            services.AddApplicationInsightsTelemetry();
#endif
            services.AddContext();
            services.AddMemoryCache();
            services.AddApiHealthChecks(Configuration);
            services
                .AddControllers(options =>
                {
                    options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true;
                    options.EnableEndpointRouting = true;
                })
                .AddValidationExceptionHandler()
                .AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
                    options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
                    options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
                });

            services
                .AddApiVersioning(c =>
                {
                    c.ReportApiVersions = true;
                    c.ApiVersionReader = new UrlSegmentApiVersionReader();
                })
                .AddVersionedApiExplorer(c =>
                {
                    c.SubstituteApiVersionInUrl = true;
                    c.GroupNameFormat = "'v'V";
                });

            services.RegisterCdmApiDependencies();

            services.AddSwagger(Configuration);

            services.AddAuth(HostEnvironment, Configuration);

            ConfigureHttpClients(services);
            ConfigureDbContext(services);
        }
        
        public void Configure(IApplicationBuilder app, IApiVersionDescriptionProvider provider)
        {
            MigrateDatabase(app);
            app.UseApiHealthChecks();

            app.UseMiddleware<GlobalExceptionHandlerMiddleware>();
            app.UseCorrelationIdInitializer();
            app.UseUserInfoInitializer();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseCustomSwagger(provider, Configuration);
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("franx-core-cdm");
                });
            });
        }

        protected virtual IServiceCollection ConfigureHttpClients(IServiceCollection services)
        {
            var userApiBaseUrl = Configuration.GetValue<string>("UserApi:BaseUrl");
            var staticDataApiBaseUrl = Configuration.GetValue<string>("StaticDataApi:BaseUrl");

            services.AddHttpClient<IUserHttpClient, UserHttpClient>((svc, client) =>
            {
                client.BaseAddress = new Uri(userApiBaseUrl);
            })
            .AddAzureAdToken(Configuration.GetSection("AzureAd").Bind, Configuration.GetValue<string>("UserApi:Scope"))
            .PropagateCorrelationId().PropagateUserInfo();

            services.AddHttpClient<IStaticDataApiClient, StaticDataApiClient>((svc, client) =>
            {
                client.BaseAddress = new Uri(staticDataApiBaseUrl);
            })
            .AddAzureAdToken(Configuration.GetSection("AzureAd").Bind, Configuration.GetValue<string>("StaticDataApi:Scope"))
            .PropagateCorrelationId().PropagateUserInfo();

            return services;
        }

        protected virtual IServiceCollection ConfigureDbContext(IServiceCollection services)
        {
            var connectionString = Configuration.GetConnectionString("Franx.CDM");

            services.AddDbContext<CDMDBContext>(options => options.UseSqlServer(connectionString,
                         sql =>
                         {
                             sql.MigrationsAssembly(typeof(CDMDBContext).Assembly.FullName);
                             sql.EnableRetryOnFailure();
                         })
                    .AddInterceptors(DbInterceptorFactory.CreateInterceptors(connectionString)));

            return services;
        }

        protected virtual void MigrateDatabase(IApplicationBuilder app)
        {
            using var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope();
            var context = serviceScope.ServiceProvider.GetService<CDMDBContext>();
            context?.Database.Migrate();
        }
    }
}
