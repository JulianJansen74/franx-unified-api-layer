﻿using System;

namespace Franx.Core.CDM.Api.Extensions.AzureAdToken
{
    public record AzureAdTokenOptions
    {
        public Uri Authority { get; set; }
        public string Audience { get; set; }
        public string ClientId => Audience;
        public string ClientSecret { get; set; }
    }
}
