﻿namespace Franx.Core.CDM.Api.Authorization
{
    public static class Roles
    {
        public const string WriteCustomerData = "write_customer_data";
        public const string ReadCustomerData = "read_customer_data";
        public const string WriteCustomerDataFromClientFile = "write_customer_data_client_file";
        public const string CreateAccount = "create_account";
        public const string ReadPortfolioAccount = "read_portfolio_account";
        public const string AdminReadCorporates = "admin_read_corporates";
        public const string AdminWriteCorporates = "admin_write_corporates";
        public const string AdminReadPortfolios = "admin_read_portfolios";
        public const string AdminWritePortfolios = "admin_write_portfolios";
        public const string AdminReadAccounts = "admin_read_accounts";
        public const string ChangeCorporateStatus = "change_corporate_status";
        public const string CloseAccount = "close_account";
        public const string DisablePortfolio = "disable_portfolio";
    }
}
