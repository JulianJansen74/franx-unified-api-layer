﻿using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace Franx.Core.CDM.Api.Authorization
{
    [ExcludeFromCodeCoverage]
    public class AllowAllAuthorizationHandler : IAuthorizationHandler
    {
        public Task HandleAsync(AuthorizationHandlerContext context)
        {
            if (context == null)
            {
                return Task.CompletedTask;
            }

            foreach (var pendingRequirement in context.PendingRequirements.ToList())
            {
                context.Succeed(pendingRequirement);
            }

            return Task.CompletedTask;
        }
    }
}
