﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Franx.Core.CDM.Api.Authorization
{
    [ExcludeFromCodeCoverage]
    public static class ServiceCollectionExtensions
    {
        public static void AddAuth(this IServiceCollection services, IHostEnvironment hostEnvironment, IConfiguration configuration)
        {
            services.AddAuthentication(options =>
            {
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {
                configuration.GetSection("AzureAd").Bind(options);
                options.TokenValidationParameters.ValidIssuer = options.Authority + "/v2.0";
            });

            services.AddAuthorization(options => options.AddPolicies());

#if DEBUG
            if (hostEnvironment.IsDevelopment())
            {
                services.AddSingleton<IAuthorizationHandler, AllowAllAuthorizationHandler>();
            }
#endif
        }

        public static void AddPolicies(this AuthorizationOptions options)
        {
            options?.AddPolicy(Roles.ReadCustomerData,
                policy => policy.RequireRole(Roles.ReadCustomerData));

            options?.AddPolicy(Roles.WriteCustomerData,
                policy => policy.RequireRole(Roles.WriteCustomerData));

            options?.AddPolicy(Roles.WriteCustomerDataFromClientFile,
                policy => policy.RequireRole(Roles.WriteCustomerDataFromClientFile));

            options?.AddPolicy(Roles.CreateAccount,
                policy => policy.RequireRole(Roles.CreateAccount));

            options?.AddPolicy(Roles.AdminReadCorporates,
                policy => policy.RequireRole(Roles.AdminReadCorporates));

            options?.AddPolicy(Roles.AdminWriteCorporates,
                policy => policy.RequireRole(Roles.AdminWriteCorporates));

            options?.AddPolicy(Roles.AdminReadPortfolios,
                policy => policy.RequireRole(Roles.AdminReadPortfolios));

            options?.AddPolicy(Roles.AdminWritePortfolios,
                policy => policy.RequireRole(Roles.AdminWritePortfolios));

            options?.AddPolicy(Roles.AdminReadAccounts,
                policy => policy.RequireRole(Roles.AdminReadAccounts));

            options?.AddPolicy(Roles.ReadPortfolioAccount,
                policy => policy.RequireRole(Roles.ReadPortfolioAccount));

            options?.AddPolicy(Roles.CloseAccount,
                policy => policy.RequireRole(Roles.CloseAccount));

            options?.AddPolicy(Roles.DisablePortfolio,
                policy => policy.RequireRole(Roles.DisablePortfolio));

            options?.AddPolicy(Roles.ChangeCorporateStatus,
                policy => policy.RequireRole(Roles.ChangeCorporateStatus));
        }
    }
}
