﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Franx.Core.CDM.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Franx.Core.CDM.Api.Middlewares;

public class GlobalExceptionHandlerMiddleware
{
    private readonly RequestDelegate _next;

    public GlobalExceptionHandlerMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex) when (ex is IAppException applicationException)
        {
            var logger = context.RequestServices.GetRequiredService<ILogger<GlobalExceptionHandlerMiddleware>>();

            logger.LogError(ex, $"Application exception has thrown");

            context.Response.StatusCode = (int)applicationException.HttpStatusCode;

            await WriteResponseAsync(context, ex, applicationException.ErrorKey.ToString());
        }
        catch (Exception ex)
        {
            var logger = context.RequestServices.GetRequiredService<ILogger<GlobalExceptionHandlerMiddleware>>();
            logger.LogError(ex, "An unhandled exception has occurred");

            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            await WriteResponseAsync(context, ex, ErrorKey.UnhandledException.ToString());
        }
    }

    private static async Task WriteResponseAsync(HttpContext context, Exception ex, string errorCode)
    {
        var response = new
        {
            Errors = new List<Error>()
            {
                new(errorCode, ex.Message.Replace(Environment.NewLine, " - "))
            }
        };

        await context.Response.WriteAsJsonAsync(response);
    }
}

public record Error(string Key, string Data);
