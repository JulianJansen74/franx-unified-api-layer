using Abf.Account.Common;
using Abf.Account.Common.Exceptions;
using Abf.Account.Models.AccountBalance;
using Abf.Account.Router.AbnRouters.AbnMappers;
using Abf.Account.Routers;
using Abfr.Abn.Gateway.Services;

namespace Abf.Account.Router.AbnRouters;

public sealed class AbnAccountBalanceRouter(AbnAmroAccountInsightClient accountInsightClient) : IAccountBalanceRouter
{
    public BackofficeName BackOfficeName => BackofficeName.AbnAmro;

    public async Task<AccountBalance[]?> GetAccountBalances(
        AccountBalanceRequest accountBalanceRequest,
        CancellationToken cancellationToken)
    {
        var accountNumber = GetRequiredAccountNumber(accountBalanceRequest.BbanAccountNumber);
        var balance = await accountInsightClient.GetAccountBalancesAsync(accountNumber, cancellationToken);

        return AbnAccountBalanceMapper.MapToAccountBalances(balance);
    }

    public async Task<decimal?> GetAccountBalanceByValueDate(string accountNumber, DateTime valueDate)
    {
        var balance = await accountInsightClient.GetAccountBalancesAsync(
            GetRequiredAccountNumber(accountNumber),
            CancellationToken.None);

        return AbnAccountBalanceMapper.MapToBalance(balance);
    }

    private static string GetRequiredAccountNumber(string? accountNumber)
    {
        if (!string.IsNullOrWhiteSpace(accountNumber))
        {
            return accountNumber;
        }

        throw new UnprocessableEntityException("Account number is required for ABN AMRO account balance.");
    }
}
