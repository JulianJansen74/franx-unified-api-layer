using Abf.Account.Models.AccountBalance;
using Abfr.Abn.Gateway.Models.Insight;

namespace Abf.Account.Router.AbnRouters.AbnMappers;

public static class AbnAccountBalanceMapper
{
    public static AccountBalance[] MapToAccountBalances(AccountBalancesResponse response) =>
    [
        new AccountBalance
        {
            Balance = response.Amount ?? 0m,
            Currency = response.Currency ?? string.Empty
        }
    ];

    public static decimal MapToBalance(AccountBalancesResponse response) =>
        response.Amount ?? 0m;
}
